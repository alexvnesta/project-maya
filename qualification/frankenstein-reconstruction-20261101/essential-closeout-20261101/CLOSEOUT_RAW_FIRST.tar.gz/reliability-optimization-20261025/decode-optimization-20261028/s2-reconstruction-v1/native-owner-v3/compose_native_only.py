"""ROOT metadata freeze for one existing qualified CPU owner stage; no launch."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys

H=Path(__file__).resolve().parent
Q=H.parent
DC=Q.parent
E=DC.parent
R=E.parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main(stage):
    sys.dont_write_bytecode=True;sys.path.insert(0,str(DC/'maya-s-comparison-v1'))
    import acquire
    gate=acquire.SelectedGate();gate()
    resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(512*2**20,)*2);os.nice(15)
    o=load('native_stage_owner',H/'owner.py');p=load('native_stage_payload',Q/'native-payload-v3/payload.py')
    assert o.sha(H/'owner.py')=='207dc8edae5d7b01e4a918e3a2276a6d2d9f43fa303b3ed023ff0cbee86482c0'
    assert o.sha(Q/'native-payload-v3/payload.py')=='c402eeee5ae68b6074d2216afb35ec3bf41989c773ef83bce0ae8ed5b5bfa9c7'
    read=lambda path:json.loads(Path(path).read_text())
    planpath=Q/'native-payload-v1/actual-plan-FIRST-linux/SOURCE_PLAN.json';plan=read(planpath);p.validate_plan(plan)
    state=read(E/'STATE.json');current=state['decode_optimization_current']
    assert current['status']=='S2_PLACEMENT_SELECTED4096_RESTORED' and current['verified']['passed'] is True
    placement=Path(current['output'])/'native/actual-placement.json'
    assert p.object_sha(read(placement))==plan['placement_sha256']
    files={}
    def add(path,pin=None):
        path=Path(path);p.regular(path);assert path.stat().st_size<=512*2**20
        actual=o.sha(path)
        if pin is not None:assert actual==pin,str(path)
        files[str(path)]=actual
    def rawfolder(root):
        for f in sorted(Path(root).rglob('*')):
            if f.is_file() and '__pycache__' not in f.parts:add(f)
    for root,names in [(H,o.SOURCES),(Q/'native-payload-v3',p.SOURCES)]:
        for n in (*names,'ROOT_SOURCE_REVIEW.json'):add(root/n)
        for platform in ('darwin','linux'):rawfolder(root/('CPU-FIRST-'+platform))
    for label in ('mac','ubuntu'):add(H/('CPU-FIRST-'+label+'.json'))
    ownerreview=read(H/'ROOT_SOURCE_REVIEW.json')
    assert ownerreview['entire_source_tests_driver_manually_read'] is True and ownerreview['source_map']==o.source_map()
    ownerproof={platform:read(H/('CPU-FIRST-'+label+'.json')) for platform,label in [('darwin','mac'),('linux','ubuntu')]}
    o.cpu_contract(ownerproof,o.source_map(),ownerreview['test_ids'])
    payloadroot=Q/'native-payload-v3';payloadreview=read(payloadroot/'ROOT_SOURCE_REVIEW.json')
    sources={n:o.sha(payloadroot/n) for n in p.SOURCES};inputs=p.input_map()
    assert payloadreview['entire_source_tests_driver_manually_read'] is True and payloadreview['sources']==sources and payloadreview['inputs']==inputs
    CPU={}
    for platform in ('darwin','linux'):
        receipt=payloadroot/('CPU-FIRST-'+platform)/'receipt.json';child=receipt.parent/'child.json'
        p.cpu_proof_contract(read(receipt),read(child),sources,inputs,payloadreview['test_ids'],platform,o.sha(payloadroot/'ROOT_SOURCE_REVIEW.json'))
        CPU[platform]={'path':str(receipt),'sha256':o.sha(receipt),'supervision_path':str(child),'supervision_sha256':o.sha(child)}
    # Immutable actual planning metadata and the first bounded reconstruction on both hosts.
    for platform in ('darwin','linux'):
        root=Q/'native-payload-v1'/('actual-plan-FIRST-'+platform);proof=read(root/'proof.json')
        assert proof['experts']==1870 and proof['roles']==5610 and proof['source_map_sha256']==plan['source_map_sha256']
        assert proof['plan_sha256']==p.object_sha(plan) and proof['header_sha256']==plan['header_sha256']
        rawfolder(root);rawfolder(Q/'native-payload-v1'/('prepare-actual-FIRST-'+platform))
    add(Q/'native-payload-v1/prepare_actual.py');add(Q/'native-payload-v1/PREPARE_ACTUAL_SOURCE_REVIEW.json')
    add(Q/'native-payload-v1/original-headers-FIRST.json');add(placement)
    for f in [p.RECIPE,p.HEADER,p.CONVERSION,p.HASH_HELPER,Q/'native-codec-v2/mxpack.cpp',
        Q/'native-codec-v2/BOTH_HOST_CPU_FIRST.json',Q/'native-codec-v2/mxpack-FIRST-linux',
        Q/'source-plan-v1/inputs/official-index-FIRST.json',Q/'source-plan-v1/inputs/official-HF-metadata-FIRST.json',
        Q/'iq3s-real-matrix-v1/original-weight.bin',Q/'iq3s-real-matrix-v1/original-scale.bin',o.BUILD,o.BULK,
        DC/'cpu-iq2xs-upstream623-v1/model-v1/cpu_driver.py',Q/'original-expert-acquisition-v2/acquisition-state.json',
        Q/'bounded-sha256-v1/qualification.json']:
        add(f)
    for n in ('fork_hash.py','test_hash.py','run_cpu.py','ROOT_SOURCE_REVIEW.json','CPU-FIRST-darwin.json','CPU-FIRST-linux.json'):
        add(Q/'bounded-sha256-v1'/n)
    for platform in ('darwin','linux'):rawfolder(Q/'bounded-sha256-v1'/('CPU-FIRST-'+platform))
    # Exact P0 closure and actual selected restoration. Only small proof files, no weights/cache copies.
    metadata=Path(current['proof_path']).parent
    for n in ('state.json','result.json','old-owner-close.json','private-memory-fence-collected.json','start-binding.json','public-default-output-request.json','public-default-output-sse.txt'):
        add(metadata/n)
    result=Path(current['output'])
    for n in ('native-start.json','native-identity.json','native-exit.json','receipt.json','private-memory-fence.json','native/engine.log'):
        add(result/n)
    window=Path(current['window']);add(window);add(window.with_suffix('.telemetry.jsonl'));add(window.with_suffix('.kernel.log'))
    add(Q/'launch-custody-v1/capture-placement-v3-P0-ADMISSION2/controller-exit.json')
    add(Q/'launch-custody-v1/qualification.json');add(Q/'launch-custody-v1/launch.py');add(H/'compose_stage.py')
    base={'stage':stage,'selected_binding':gate.host.start_binding,'entire_source_tests_driver_manually_read':True,
        'source_sha256':o.source_map(),'source_root':str(o.ROOT),'test_ids':ownerreview['test_ids'],
        'CPU_paths':{platform:str(H/('CPU-FIRST-'+label+'.json')) for platform,label in [('darwin','mac'),('linux','ubuntu')]},
        'CPU_child_paths':{platform:str(H/('CPU-FIRST-'+platform)/'child.json') for platform in ('darwin','linux')},
        'files':files,'payload_source_sha256':o.sha(payloadroot/'payload.py'),'plan_path':str(planpath),'plan_sha256':o.sha(planpath),
        'scope':'ONE original29 full-source verification' if stage=='verify' else 'ONE original1870x3 native payload; no model or service action'}
    if stage=='native':
        verifyroot=H/'verify-FIRST';assert read(verifyroot/'result.json')['passed'] is True
        verification=H/'verify-qualification.json'
        verified_q,_,_=o.qualified('verify',o.sha(verification));assert verified_q['selected_binding']==gate.host.start_binding
        add(verification)
        independent=H/'ORIGINAL_SOURCE_FIRST_INDEPENDENT_REVIEW.json';assert read(independent)['passed'] is True;add(independent)
        captured=Q/'launch-custody-v1/capture-native-verify-FIRST'
        outer=read(captured/'controller-exit.json');attempt=read(verifyroot/'attempt.json')
        assert outer['pid']==attempt['controller_pid'] and outer['returncode']==0 and outer['actual_wait_observed'] is True
        assert outer['error'] is None and outer['cleanup']==[] and outer['retry'] is False and outer['target_signals_sent']==0
        for f in captured.iterdir():
            if f.is_file():add(f)
        add(H/'compose_native_only.py')
        assert read(verifyroot/'supervision.json')['owned_claim_released'] is True
        receipt=verifyroot/'original-sources.json';p.source_contract(plan,read(receipt),o.ROOT)
        rawfolder(verifyroot)
        pq={'entire_source_tests_driver_manually_read':True,'CPU_both_hosts_passed':True,'sources':sources,'inputs':inputs,
            'test_ids':payloadreview['test_ids'],'CPU':CPU,'source_review_sha256':o.sha(payloadroot/'ROOT_SOURCE_REVIEW.json'),
            'output_directory':str(payloadroot/'native-FIRST'),'source_root':str(o.ROOT),
            'plan':{'path':str(planpath),'sha256':o.sha(planpath)},'source_receipt':{'path':str(receipt),'sha256':o.sha(receipt)},
            'placement':{'path':str(placement),'sha256':o.sha(placement)},'selected_binding':gate.host.start_binding,
            'outer_CPU_custody_required':True,'source_map_sha256':plan['source_map_sha256'],
            'bounded_hash_qualification':str(Q/'bounded-sha256-v1/qualification.json'),'files':dict(files)}
        path=payloadroot/'qualification.json';o.emit(path,pq);pin=o.sha(path);p.qualification(path,pin);add(path)
        base['native_qualification_sha256']=pin
    path=H/(stage+'-qualification.json');o.emit(path,base);pin=o.sha(path);o.qualified(stage,pin)
    plan={'ROOT_explicit_admission':True,'no_replay':True,'target_owns_bounds_and_restore':True,
        'argv':[str(R/'venv/bin/python3.14'),'-I','-B',str(H/'owner.py'),'--stage',stage,'--qualification-sha256',pin],
        'target_source_sha256':o.sha(H/'owner.py'),'cwd':str(H),'output':str(Q/'launch-custody-v1'/('capture-native-'+stage+'-FIRST'))}
    lp=Q/'launch-custody-v1'/('native-'+stage+'-FIRST-plan.json');o.emit(lp,plan)
    print(json.dumps({'stage':stage,'qualification_sha256':pin,'launch_plan_sha256':o.sha(lp),'files':len(files),'sources':len(read(planpath)['source_headers'])}))

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--stage',choices=['native'],required=True);main(a.parse_args().stage)
