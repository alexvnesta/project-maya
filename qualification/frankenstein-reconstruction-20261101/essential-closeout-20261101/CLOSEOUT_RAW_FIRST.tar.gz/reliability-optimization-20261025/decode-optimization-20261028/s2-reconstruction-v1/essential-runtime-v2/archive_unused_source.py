"""Audited transport invocation using unchanged both-host-qualified copy/hash custody.
Only the unused official source23 is relocated; no runtime/fixture/model delta.
"""
import importlib.util,json,os,sys,hashlib
from pathlib import Path
H=Path(__file__).resolve().parent;Q=H.parent;DC=Q.parent;E=DC.parent
OUT=H/'unused-source23-FIRST'
SRC=Q/'iq3s-source-acquisition-v1/assets/original/model-00023-of-00048.safetensors'
DEST=Path('/data2/deepseek-frankenstein-evidence-20261101/unused-original-sources/model-00023-of-00048.safetensors')
PIN='d6e47e8b7147c64eb6619732694dda811e1a9f8af1894977919af9522724ca31'
def load(name,path,pin):
 assert hashlib.sha256(path.read_bytes()).hexdigest()==pin
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def main():
 sys.dont_write_bytecode=True
 a=load('existing_archive_functions',Q/'failed-join-archive-v1/archive.py','04a40f841e20eb54bd1055075aacb7a607c04d9e3bbe5e5f7253cfdb95ccfbac')
 d=load('qualified_transport_bounds',DC/'cpu-iq2xs-upstream623-v1/model-v1/cpu_driver.py','3cbcf0ce9e000035c893d033b2a6fe09e8d555a831d12a08681f5fdbb0de6b71')
 if len(sys.argv)>1:
  d.bounds(d.observed(),os.getpid(),int(sys.argv[2]));mode=sys.argv[1];saved=json.loads((OUT/'plan.json').read_text())
  expected=saved['source_fingerprint'];partial=DEST.with_suffix('.copying')
  if mode=='copy':result=a.copy_exact(SRC,partial,expected)
  else:
   assert mode=='verify';result=a.components().hash_helper().file_sha256(partial)
  with (OUT/(mode+'-result.json')).open('x') as f:json.dump({'observed':d.observed(),'result':result},f,indent=2);f.write('\n')
  return
 sys.path.insert(0,str(DC/'maya-s-comparison-v1'));import acquire;g=acquire.SelectedGate();g()
 assert not OUT.exists() and not DEST.exists() and not DEST.with_suffix('.copying').exists()
 verified=json.loads((Q/'native-owner-v3/verify-FIRST/original-sources.json').read_text())
 plan=json.loads((Q/'native-payload-v1/actual-plan-FIRST-linux/SOURCE_PLAN.json').read_text())
 assert SRC.name not in verified['files'] and SRC.name not in plan['source_headers']
 assert not any(SRC.name in json.dumps(r) for r in plan['records'])
 assert SRC.name not in ('model-00027-of-00048.safetensors','model-00028-of-00048.safetensors','model-00029-of-00048.safetensors','model-00030-of-00048.safetensors','model-00031-of-00048.safetensors')
 terminal=json.loads((Q/'original-expert-acquisition-v2/acquisition-state.json').read_text())
 row=next(v for v in terminal['files'] if Path(v['path']).name==SRC.name);assert row['sha256']==PIN and row['bytes']==7400713088
 # Reuse previously completed eight controls on each physical host, no re-execution.
 review=json.loads((Q/'failed-join-archive-v1/ROOT_SOURCE_REVIEW.json').read_text())
 for platform in ('darwin','linux'):
  root=Q/'failed-join-archive-v1';a.components().cpu_contract(json.loads((root/('CPU-FIRST-'+platform+'.json')).read_text()),json.loads((root/('CPU-FIRST-'+platform)/'child.json').read_text()),review,platform)
 import shutil
 assert shutil.disk_usage('/').free>=120*2**30 and shutil.disk_usage('/data2').free>row['bytes']
 OUT.mkdir();DEST.parent.mkdir(parents=True,exist_ok=True)
 saved={'source':str(SRC),'source_fingerprint':a.components().regular(SRC),'destination':str(DEST),'published_sha256':PIN,'unused_by_runtime_native_payload_and_IQ3S':True,'binding':g.host.start_binding}
 with (OUT/'plan.json').open('x') as f:json.dump(saved,f,indent=2);f.write('\n')
 for mode in ('copy','verify'):
  folder=OUT/mode;folder.mkdir();d.environment=lambda:dict(a.ENV, MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
  raw=d.supervise([sys.executable,'-I','-B',str(H/'archive_unused_source.py'),mode,str(os.getpid())],folder)
  assert raw['returncode']==0 and raw['error'] is None and raw['cleanup']==[],raw
  with (OUT/(mode+'-supervision.json')).open('x') as f:json.dump(raw,f,indent=2);f.write('\n')
 copy=json.loads((OUT/'copy-result.json').read_text())['result'];verify=json.loads((OUT/'verify-result.json').read_text())['result']
 assert copy['sha256']==verify['sha256']==PIN and copy['bytes']==verify['bytes']==row['bytes']
 result=a.publish_and_unlink(SRC,DEST.with_suffix('.copying'),DEST,saved['source_fingerprint'],copy,verify,OUT/'BEFORE-UNLINK.json')
 g();assert shutil.disk_usage('/').free>=132*2**30
 with (OUT/'result.json').open('x') as f:json.dump(dict(result,whole_model_executed=False,root_free_bytes=shutil.disk_usage('/').free),f,indent=2);f.write('\n')
 print(json.dumps({'passed':True,'preserved_bytes':result['bytes'],'root_free_GiB':shutil.disk_usage('/').free/2**30}))
if __name__=='__main__':main()
