"""ROOT-reviewed metadata composition only. No private arm, native, service or request."""
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys
import types

H=Path(__file__).resolve().parent;Q=H.parent;DC=Q.parent;E=DC.parent;R=E.parent
D=Path('/home/alex/deepseek-hosted-20261025')

def main():
    sys.dont_write_bytecode=True;sys.path.insert(0,str(DC/'maya-s-comparison-v1'))
    import acquire
    gate=acquire.SelectedGate();gate()
    resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(512*2**20,)*2);os.nice(15)
    def load(name,path):
        sys.path.insert(0,str(path.parent));s=importlib.util.spec_from_file_location(name,path)
        m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
    rt=load('essential_prepare_runtime',H/'runtime.py')
    read=lambda p:json.loads(Path(p).read_text())
    pub=Q/'publication-chain-v4/PUBLICATIONS_B0_FIRST.json'
    assert rt.sha(pub)=='99146a70de20efa25739edf75851d28bdcb9bb2396545e1306a79f4c7a064a42'
    q=read(pub);assert q['selected_binding']==gate.host.start_binding
    def add(path,pin=None):
        path=Path(path);assert rt.fingerprint(path)[2]<=512*2**20,str(path)
        value=rt.sha(path)
        if pin is not None:assert value==pin,str(path)
        if str(path) in q['files']:assert q['files'][str(path)]==value,('Old pin changed',str(path))
        q['files'][str(path)]=value;return str(path)
    prior=Q/'placement-v3/qualification.json';assert rt.sha(prior)=='2db5883de479a33e6e4a2b0f9401c7881c6cac25df29eca93e6422029861a28d'
    for n,v in read(prior)['files'].items():add(n,v)
    add(prior);add(pub);add(H/'prepare_b0.py')
    # These owned component roots contain small source and FIRST raw CPU evidence only.
    for sub in ('essential-runtime-v2','essential-panel-v1','essential-fixtures-v3','essential-audit-v2','baseline-startup-v1'):
        for p in sorted((Q/sub).rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts and p.name not in ('qualification.json','arms.json') and not p.name.endswith('-admission.json'):add(p)
    add(Q/'ESSENTIAL_SELECTION_CRITERIA.json')
    for name in rt.SELECTED92_SOURCE:add(DC/'maya145-formal-prefill-v1/selected92-source'/name,rt.SELECTED92_SOURCE[name])
    add(DC/'iq2s-persistent-v1/gpu-qualification.json','cd146a86438054e664b6dfb953341fc65ecb34d9ab6d9d22851009c239713580')
    add(DC/'maya145-directstate-v1/engine_profile.py')
    add(DC/'model-v1/imma_numeric_controls.py')
    add(D/'hosting_defaults.py')
    for sub in ('serve','tools'):
        for p in sorted((D/'runtime-native-vision-v2'/sub).rglob('*.py')):add(p)
    selected=read(DC/'maya-s-comparison-v1/model-v1/pack-state-A.json')
    for pack in (Q/'candidate-pack-v1/pack-FIRST',Path(selected['pack'])):
        for n in ('ds4.txt','tensors.txt','engram.bin'):add(pack/n)
        for p in sorted((pack/'tokenizer').rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:add(p)
    q.update(mode=rt.MODE,root_entire_source_tests_driver_read=True,
      policy={'context':1048576,'output':262144,'effort':100,'cap':32768,'chunk':4096,'cpu_threads':24,'static_tp':1,'all_cpu_RAM':True},
      old_arms_closed=True,prospective_owned_restore_qualified=True,weight_materialization_closed=True,all_bulk_source_workers_closed=True,
      CPU_review=str(H/'ROOT_SOURCE_REVIEW.json'),
      CPU={p:{'receipt':str(H/('CPU-FIRST-'+p+'.json')),'child':str(H/('CPU-FIRST-'+p)/'child.json'),'log':str(H/('CPU-FIRST-'+p)/'child.log')} for p in ('darwin','linux')},
      native_payload_source_three_role_CPU_qualified=True,actual_P0_selection_frozen=True)
    assets=q['large_verified'];selected_assets=[n for n,v in assets.items() if v['chain']=='SELECTED92_EXISTING']
    vision=[n for n in selected_assets if 'vision' in n.lower()];assert len(vision)==1
    q['profiles']={
      'B0':{'exe':str(Q/'native-build-v2/native-build-FIRST/maya-ds4'),'native_sha256':'c942a4cf8047d154dd2201b3541b4653c70d88e687b3c014dc649eb09beaac86',
            'pack':str(Q/'candidate-pack-v1/pack-FIRST'),'manifest':str(Q/'essential-fixtures-v3/CPU-FIRST-linux/manifest-B0.json'),
            'manifest_CPU_encoding_actual_pack_qualified':True,'pack_constructor_proof':str(Q/'candidate-pack-v1/CONSTRUCTION_FIRST.json'),
            'asset_paths':[n for n,v in assets.items() if v['chain']!='SELECTED92_EXISTING']+vision,
            'native_payload':str(Q/'native-payload-v3/native-FIRST/native.cpu'),
            'native_artifact_sha256':'0f04dfb9c92aff7ef91214b8f8f646b9b2cf71f6b4b622c9206318f24dc7d6d8',
            'native_map_sha256':'c28e9b1c9a5e0b539f7db849decdc528b7984e60ae4c2ec54189538016cced2d',
            'map_path':str(Q/'native-payload-v1/actual-plan-FIRST-linux/SOURCE_PLAN.json'),
            'overlay_path':str(Q/'iq3s-bulk-v1/conversion-FIRST/overlay.iq3s')},
      'A0':{'exe':str(D/'bin/maya-ds4'),'native_sha256':rt.BASE_NATIVE,'pack':selected['pack'],
            'manifest':str(Q/'essential-fixtures-v3/CPU-FIRST-linux/manifest-A0.json'),
            'manifest_CPU_encoding_actual_pack_qualified':True,'pack_constructor_proof':str(DC/'maya-s-comparison-v1/model-v1/pack-state-A.json'),
            'asset_paths':selected_assets,'startup_adapter':str(Q/'baseline-startup-v1/startup.py'),'startup_adapter_CPU_source_qualified':True}}
    # Materialize the already reviewed import closure without running any controller.
    p2=load('s2_essential_placement2',Q/'placement-v2/placement.py');support=p2.support()
    for n,rel in (('ms_fixtures','maya-s-comparison-v1/model-v1/ms_fixtures.py'),
                  ('ae_config','adaptive-expert-cache-v1/performance-v1/ae_config.py'),
                  ('ae_runtime','adaptive-expert-cache-v1/performance-v1/ae_runtime.py'),
                  ('ae_controls','adaptive-expert-cache-v1/performance-v1/ae_controls.py')):
        path=DC/rel
        if n not in sys.modules:load(n,path)
        else:assert Path(sys.modules[n].__file__).resolve()==path
    sys.modules['pv_runtime'].lifecycle_helper()
    origins={}
    for name,module in list(sys.modules.items()):
        path=getattr(module,'__file__',None)
        if path and str(path).startswith(str(R)+'/') and '/venv/' not in str(path):
            path=Path(path).resolve()
            if path.suffix=='.py':origins[name]=add(path)
    old=support[1];origins['q8_phase']=add(Path(old.q8_phase.__file__).resolve())
    for module in support:
        add(module.__file__)
        for value in vars(module).values():
            if isinstance(value,types.ModuleType):
                path=getattr(value,'__file__',None)
                if path and str(path).startswith(str(R)+'/') and '/venv/' not in str(path) and Path(path).suffix=='.py':add(path)
    q['import_origins']=origins
    # A metadata-only prevalidation also checks token IDs and no global fixture repointing.
    rt.helpers(q)
    for arm in ('B0','A0'):
        manifest=read(q['profiles'][arm]['manifest']);rt.fixture_contract(manifest,sys.modules['ms_fixtures'],arm)
    out=H/'qualification.json';assert not out.exists()
    with out.open('x') as f:json.dump(q,f,indent=2,allow_nan=False);f.write('\n')
    pin=rt.sha(out);rt.qualified(pin,'B0')
    with (H/'qualification-B0-FIRST.json').open('x') as f:json.dump(q,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({'passed':True,'qualification_sha256':pin,'files':len(q['files']),'origins':len(origins),'selected_binding':gate.host.start_binding,'model_executed':False}))

if __name__=='__main__':main()
