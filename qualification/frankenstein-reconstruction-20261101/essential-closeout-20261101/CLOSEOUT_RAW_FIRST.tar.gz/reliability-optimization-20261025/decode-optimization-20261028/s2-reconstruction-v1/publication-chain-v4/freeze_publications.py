"""ROOT-only metadata proposal for four closed artifact chains; never infer."""
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys

H=Path(__file__).resolve().parent
Q=H.parent
DC=Q.parent
E=DC.parent
R=E.parent

def main():
    sys.dont_write_bytecode=True;sys.path.insert(0,str(DC/'maya-s-comparison-v1'))
    import acquire
    gate=acquire.SelectedGate();gate()
    resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_AS,(512*2**20,)*2);os.nice(15)
    spec=importlib.util.spec_from_file_location('freeze_actual_publications',H/'chain.py')
    c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
    read=lambda p:json.loads(Path(p).read_text())
    def emit(path,value):
        with Path(path).open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
    files={};groups={};large={}
    def add(path,pin=None):
        path=Path(path);assert c.fingerprint(path)[2]<=512*2**20,str(path)
        digest=c.sha(path)
        if pin is not None:assert digest==pin,str(path)
        files[str(path)]=digest;return str(path)
    def folder(root,group=None):
        for path in sorted(Path(root).rglob('*')):
            if not path.is_file() or '__pycache__' in path.parts:continue
            if path.name in ('native.cpu','native.partial','overlay.iq3s','overlay.partial'):continue
            n=add(path)
            if group is not None:group.add(n)
    def snap(path,kind,result,paths,**extra):
        value={'schema':'s2-publication-fingerprints-v1','kind':kind,'source_result_path':str(result),
               'source_result_sha256':c.sha(result),'files':{str(p):{'fingerprint':c.fingerprint(p),'published_inode':c.fingerprint(p)[:3]} for p in paths},**extra}
        emit(path,value);add(path);return str(path),value
    def register(key,group,raw):
        group['raw_paths']=sorted(raw);groups[key]=group
    def assets(key,snapshot,hashes):
        for name,h in hashes.items():
            assert name not in large
            large[name]={'chain':key,'sha256':h,'fingerprint':snapshot['files'][name]['fingerprint']}
    # Actual own FIRST14 proof. Source/CPU changes are already closed on both hosts.
    review=read(H/'ROOT_SOURCE_REVIEW.json')
    own={'sources':{n:c.sha(H/n) for n in c.SOURCES},'inputs':review['input_map'],
         'test_ids':review['test_ids'],'source_review':str(H/'ROOT_SOURCE_REVIEW.json'),
         'CPU':{p:{'receipt':str(H/('CPU-FIRST-'+p+'.json')),'child':str(H/('CPU-FIRST-'+p)/'child.json'),
                   'log':str(H/('CPU-FIRST-'+p)/'child.log')} for p in ('darwin','linux')}}
    assert own['sources']==review['source_map'] and len(own['test_ids'])==14
    for platform,paths in own['CPU'].items():c.cpu_contract(read(paths['receipt']),read(paths['child']),review,platform)
    qp=H/'qualification.json';emit(qp,own)
    for n in (*c.SOURCES,'ROOT_SOURCE_REVIEW.json','qualification.json','freeze_publications.py'):add(H/n)
    for platform,paths in own['CPU'].items():
        for path in paths.values():add(path)
    add(DC/'cpu-iq2xs-upstream623-v1/model-v1/cpu_driver.py')
    # ALL8 source acquisition, with the genuine historical outer-exit limitation.
    root=Q/'base-acquisition-v2';terminal=root/'acquisition-state.json';attempt=root/'acquisition-attempt-20261101T143519682784Z-1457149.json'
    t=read(terminal);assert t==read(attempt) and t['pid']==1457149
    raw=set();folder(root,raw)
    observer=H/'base-outer-exit-UNKNOWN-FIRST.json'
    emit(observer,{'pid':1457149,'source_path':str(root/'acquire.py'),'source_sha256':c.sha(root/'acquire.py'),
          'returncode':None,'status':'UNKNOWN','start_ticks':181198662,'start_ticks_status':'RECORDED',
          'limitation':'Terminal reports intended returncode0 before print; actual outer exit unobserved'})
    raw.add(add(observer));constructor=Q/'candidate-pack-v1/CONSTRUCTION_FIRST.json';raw.add(add(constructor))
    cr=Q/'candidate-pack-v1';rv=read(cr/'ROOT_SOURCE_REVIEW.json')
    for n in ('construct_pack.py','ROOT_SOURCE_REVIEW.json','CPU-FIRST-mac.json','CPU-FIRST-ubuntu.json','child-FIRST-mac.json','child-FIRST-ubuntu.json',*rv['source_sha256']):raw.add(add(cr/n))
    for n,h in rv['input_sha256'].items():raw.add(add(Q/n.removeprefix('shared/') if n.startswith('shared/') else cr/n,h))
    for n,h in read(constructor)['outputs'].items():raw.add(add(cr/'pack-FIRST'/n,h['sha256']))
    names=[Q/'base-acquisition-v1/assets'/v['path'] for v in t['files']]
    lock=Q/'base-acquisition-v1/acquisition.lock';lockrow={'path':str(lock),'fingerprint':c.fingerprint(lock)}
    with c.writer_free(lockrow):pass
    sp,ss=snap(H/'base-PUBLICATION-FIRST.json','base-acquisition-publication',terminal,names,writer_lock=lockrow);raw.add(sp)
    g={'kind':'base-acquisition-publication','source':str(root/'acquire.py'),'qualification':str(root/'acquisition-qualification.json'),
       'manifest':str(root/'ASSET_MANIFEST.json'),'terminal':str(terminal),'attempt':str(attempt),'outer_exit_observer':str(observer),
       'constructor':str(constructor),'constructed_pack':str(cr/'pack-FIRST'),'publication_snapshot':sp}
    register('MAYA_S_ALL8',g,raw);assets('MAYA_S_ALL8',ss,{str(n):v['sha256'] for n,v in zip(names,t['files'])})
    # Separate successful assembly-v3, not the failed original join.
    ar=Q/'iq3s-assembly-v3';raw=set();folder(ar/'assembly-FIRST',raw);aq=read(ar/'qualification.json')
    for n,h in aq['files'].items():raw.add(add(n,h))
    for n in ('assembly.py','test_assembly.py','run_cpu.py','qualification.json'):raw.add(add(ar/n))
    for index,pins in aq['part_proof_sha256'].items():
        stem=Q/'iq3s-bulk-v1/conversion-FIRST/parts'/('%04d'%int(index))
        for suffix,h in pins.items():raw.add(add(stem.with_suffix(suffix),h))
    capture=Q/'launch-custody-v1/capture-assembly-FIRST';folder(capture,raw);raw.add(add(Q/'launch-custody-v1/launch.py'))
    result=ar/'assembly-FIRST/result.json';artifact=Path(read(result)['artifact_path'])
    sp,ss=snap(H/'overlay-PUBLICATION-FIRST.json','bounded-overlay-join',result,[artifact]);raw.add(sp)
    g={'kind':'bounded-overlay-join','source':str(ar/'assembly.py'),'qualification':str(ar/'qualification.json'),
       'result':str(result),'artifact':str(artifact),'publication_snapshot':sp,
       'controller_start':str(capture/'controller-start.json'),'controller_exit':str(capture/'controller-exit.json')}
    register('IQ3S_L24_28',g,raw);assets('IQ3S_L24_28',ss,{str(artifact):read(result)['sha256']})
    # Actual original-native1870 materialization: every worker and finalizer closed.
    pr=Q/'native-payload-v3';nr=Q/'native-owner-v3';raw=set()
    folder(pr/'native-FIRST',raw);folder(nr/'native-FIRST',raw);folder(nr/'verify-FIRST',raw)
    pq=read(pr/'qualification.json');nq=read(nr/'native-qualification.json')
    for n,h in {**pq['files'],**nq['files']}.items():raw.add(add(n,h))
    for root,names0 in [(pr,('payload.py','test_payload.py','run_cpu.py','qualification.json')),
                        (nr,('owner.py','test_owner.py','run_cpu.py','native-qualification.json','verify-qualification.json'))]:
        for n in names0:raw.add(add(root/n))
    capture=Q/'launch-custody-v1/capture-native-native-FIRST';folder(capture,raw)
    result=pr/'native-FIRST/result.json';artifact=Path(read(result)['artifact_path'])
    sp,ss=snap(H/'native-PUBLICATION-FIRST.json','bounded-native-finalize',result,[artifact]);raw.add(sp)
    g={'kind':'bounded-native-finalize','source':str(pr/'payload.py'),'qualification':str(pr/'qualification.json'),
       'owner_source':str(nr/'owner.py'),'owner_qualification':str(nr/'native-qualification.json'),'result':str(result),
       'artifact':str(artifact),'publication_snapshot':sp,'controller_start':str(capture/'controller-start.json'),
       'controller_exit':str(capture/'controller-exit.json')}
    register('ORIGINAL_NATIVE1870',g,raw);assets('ORIGINAL_NATIVE1870',ss,{str(artifact):read(result)['artifact_sha256']})
    # Exact currently restored selected92 seven-file inventory; no new huge SHA claim.
    state=read(E/'STATE.json');current=state['decode_optimization_current'];assert current['status']=='S2_PLACEMENT_SELECTED4096_RESTORED'
    assert current['verified']['selected_identity']['start_binding']==gate.host.start_binding
    metadata=Path(current['proof_path']).parent;restoration=metadata/'result.json';window=Path(current['window'])
    packstate=DC/'maya-s-comparison-v1/model-v1/pack-state-A.json';selected=read(packstate)
    names=[Path(n) for n in c.selected_inventory(selected)];raw=set()
    release=DC/'iq2s-persistent-v1/gpu-qualification.json'
    for f in [release,restoration,window,window.with_suffix('.telemetry.jsonl'),metadata/'public-default-output-sse.txt',packstate,
              Path(selected['pack'])/'ds4.txt',Path(selected['pack'])/'tensors.txt']:raw.add(add(f))
    sp,ss=snap(H/'selected-PUBLICATION-FIRST.json','selected-publication',restoration,names,selected_binding=gate.host.start_binding);raw.add(sp)
    g={'kind':'selected-publication','release':str(release),'restoration':str(restoration),'window':str(window),
       'window_telemetry':str(window.with_suffix('.telemetry.jsonl')),'public_sse':str(metadata/'public-default-output-sse.txt'),
       'pack_state':str(packstate),'publication_snapshot':sp}
    register('SELECTED92_EXISTING',g,raw);assets('SELECTED92_EXISTING',ss,{str(n):None for n in names})
    proposal={'files':files,'artifact_chains':groups,'large_verified':large,'selected_binding':gate.host.start_binding,
       'artifact_chain_validator':{'path':str(H/'chain.py'),'qualification_path':str(qp),
          'both_physical_CPU_qualified':True,'source_and_raw_group_schema_manually_read':True,
          'raw_CPU_paths':[n for p in own['CPU'].values() for n in p.values()]}}
    c.validate_publications(proposal)
    out=H/'PUBLICATIONS_B0_FIRST.json';emit(out,proposal)
    print(json.dumps({'passed':True,'files':len(files),'artifact_chains':len(groups),'assets':len(large),'proposal_sha256':c.sha(out)}))

if __name__=='__main__':main()
