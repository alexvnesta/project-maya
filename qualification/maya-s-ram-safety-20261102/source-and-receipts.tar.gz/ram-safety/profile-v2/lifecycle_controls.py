"""Independent bounded mocked activation/cleanup audit. No model/service actions."""
import argparse
import contextlib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import ram_activate as activation


class LifecycleTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name); self.e = self.root / 'E'; self.e.mkdir()
        self.old_binding = {'invocation': 'a'*32, 'main_pid': 10, 'native_pid': 11, 'native_start_ticks': 100}
        self.new_binding = {'invocation': 'b'*32, 'main_pid': 20, 'native_pid': 21, 'native_start_ticks': 200}
        self.initial = {'decode_optimization_current': {'selected_identity': {'native_pid': 11, 'start_binding': self.old_binding}}}
        self.state = self.e / 'STATE.json'; self.state.write_text(json.dumps(self.initial))
        self.d = self.root / 'D'; self.d.mkdir(); (self.d / 'release.json').write_text('{}')
        self.calls = []; self.fail_at = None; test = self
        def call(name):
            test.calls.append(name)
            if test.fail_at == name: raise RuntimeError('fixture failure: ' + name)
        self.call = call
        class Old:
            def guard_binding(self, *_): call('old_guard')
            def target_identity(self): call('old_identity'); return test.initial['decode_optimization_current']['selected_identity']
            def get(self, path): return {'loaded': True, 'images': True, 'max_context': 1048576, 'switcher': {'active_model': 'deepseek', 'default_model': 'deepseek', 'fault': None}}
            def stop_router(self): call('router_stop')
            def stop_ds(self): call('old_stop')
            def clean_stop(self, pid): test.assertEqual(pid, 11); call('old_close_verified')
            def free(self): call('resources_free')
            def kernel(self, since): call('kernel')
            def publication_lock(self): return contextlib.nullcontext()
            def command(self, argv, **_): test.assertEqual(argv, ['systemctl', '--user', 'daemon-reload']); call('daemon_reload')
        class Target:
            old_close_verified = False
            def clean_stop(self, pid):
                test.assertEqual(pid, 11); call('old_close_verified'); self.old_close_verified = True
            def free(self): call('resources_free')
            def kernel(self, since): call('kernel')
            def restore_ds(self):
                if not self.old_close_verified: raise RuntimeError('Missing verified closure on startup owner')
                self.start_binding = test.new_binding; self.restored_pid = 21; call('new_start')
            def restore_router(self): call('router_restore')
            def verify_target(self, expected_pid):
                test.assertEqual(expected_pid, 21); call('public_verify')
                return {'passed': True, 'selected_identity': self.target_identity()}
            def target_identity(self): return {'native_pid': 21, 'start_binding': test.new_binding}
            def cleanup_owned_target(self, pid): test.assertEqual(pid, 21); call('owned_cleanup')
        self.old = Old(); self.target = Target()
        def emit(path, value): Path(path).write_text(json.dumps(value))
        def cas(path, raw, value):
            test.assertEqual(Path(path).read_bytes(), raw); Path(path).write_text(json.dumps(value))
        self.previous = types.SimpleNamespace(production_host=lambda *_: lambda: self.old,
                                              cas_library=lambda _: types.SimpleNamespace(cas_state=cas), emit=emit)
        def publish(*_):
            self.assertIn('old_close_verified', self.calls); self.assertIn('resources_free', self.calls)
            call('publish'); return {'fixture': 'publication'}
        patches = [patch.object(activation, 'HERE', self.root), patch.object(activation, 'E', self.e),
                   patch.object(activation, 'D', self.d), patch.object(activation, 'qualified', return_value={'selected_binding': self.old_binding}),
                   patch.object(activation, 'support', return_value=(self.previous, {}, None, None)),
                   patch.object(activation, 'target_host', return_value=lambda: self.target),
                   patch.object(activation, 'publish', side_effect=publish),
                   patch.object(activation.shutil, 'disk_usage', return_value=types.SimpleNamespace(free=1000*2**30))]
        for p in patches: p.start(); self.addCleanup(p.stop)

    def test_proof_on_different_host_cannot_authorize_start(self):
        self.old.old_close_verified = True
        with self.assertRaises(RuntimeError): self.target.restore_ds()
        self.assertNotIn('new_start', self.calls)

    def test_success_single_start_after_exact_old_closure(self):
        r = activation.run('fixture')
        self.assertEqual(r['status'], 'MAYAS_TP2_RAM_GUARDS_ACTIVE_VERIFIED')
        self.assertEqual(self.calls.count('new_start'), 1)
        self.assertLess(self.calls.index('old_close_verified'), self.calls.index('publish'))
        self.assertLess(self.calls.index('publish'), self.calls.index('new_start'))
        self.assertEqual(json.loads(self.state.read_text())['current_native_pid'], 21)

    def test_failed_old_close_blocks_publication_and_start(self):
        self.fail_at = 'old_close_verified'
        with self.assertRaises(RuntimeError): activation.run('fixture')
        self.assertNotIn('publish', self.calls); self.assertNotIn('new_start', self.calls)
        self.assertEqual(json.loads(self.state.read_text())['mayas_ram_activation_v2']['status'], 'HOLD_RAM_ACTIVATION_NO_RETRY')

    def test_publication_failure_never_starts_candidate(self):
        self.fail_at = 'publish'
        with self.assertRaises(RuntimeError): activation.run('fixture')
        self.assertNotIn('new_start', self.calls)

    def test_start_failure_owned_cleanup_no_retry(self):
        self.fail_at = 'new_start'
        with self.assertRaises(RuntimeError): activation.run('fixture')
        self.assertEqual(self.calls.count('new_start'), 1); self.assertEqual(self.calls.count('owned_cleanup'), 1)
        self.assertTrue(json.loads(self.state.read_text())['mayas_ram_activation_v2']['original_failed_attempt_preserved'])

    def test_public_failure_owned_cleanup_no_regrade(self):
        self.fail_at = 'public_verify'
        with self.assertRaises(RuntimeError): activation.run('fixture')
        self.assertEqual(self.calls.count('public_verify'), 1); self.assertEqual(self.calls.count('owned_cleanup'), 1)

    def test_foreign_custody_never_signals_replacement(self):
        def foreign():
            current = json.loads(self.state.read_text()); current['mayas_ram_activation_v2'] = {'foreign': True}
            self.state.write_text(json.dumps(current)); raise RuntimeError('foreign fixture')
        self.target.restore_ds = foreign
        with self.assertRaises(RuntimeError): activation.run('fixture')
        self.assertNotIn('owned_cleanup', self.calls)
        self.assertEqual(json.loads(self.state.read_text())['mayas_ram_activation_v2'], {'foreign': True})


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--child', action='store_true'); ap.add_argument('--parent', type=int)
    ap.add_argument('--review-sha256', required=True); args = ap.parse_args()
    review_file = HERE / 'LIFECYCLE_REVIEW.json'
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    if sha(review_file) != args.review_sha256: raise ValueError('Exact manually read independent audit')
    review = json.loads(review_file.read_text())
    if not review['entire_source_tests_read'] or {n: sha(HERE/n) for n in review['source_map']} != review['source_map']:
        raise ValueError('Audit source drift')
    root = Path('/Users/alex/strata-deepseek-qualification-20261024') if sys.platform == 'darwin' else Path('/home/alex/strata-deepseek-test-20261024')
    driver = root / 'reliability-optimization-20261025/decode-optimization-20261028/cpu-iq2xs-upstream623-v1/model-v1/cpu_driver.py'
    if sha(driver) != '3cbcf0ce9e000035c893d033b2a6fe09e8d555a831d12a08681f5fdbb0de6b71': raise ValueError('Existing bounded supervisor')
    spec = importlib.util.spec_from_file_location('bounded_audit', driver); d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)
    if not args.child:
        folder = HERE / ('LIFECYCLE_CPU_FIRST_' + sys.platform); folder.mkdir()
        d.environment = lambda: {**d.ENV, 'PATH': '/usr/bin:/bin'}
        r = d.supervise([sys.executable, '-I', '-B', str(HERE / 'lifecycle_controls.py'), '--review-sha256', args.review_sha256,
                         '--child', '--parent', str(os.getpid())], folder)
        print(json.dumps(r)); return 0 if r['returncode'] == 0 and not r['error'] and not r['cleanup'] else 1
    ob = d.observed(); d.bounds(ob, os.getpid(), args.parent)
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(LifecycleTests); ids = d.flatten(suite)
    if ids != review['test_ids']: raise ValueError('Exact independent controls')
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    with (HERE / ('LIFECYCLE_CPU_FIRST_' + sys.platform + '.json')).open('x') as f:
        json.dump({'passed': result.wasSuccessful(), 'controls': result.testsRun, 'test_ids': ids, 'observed': ob,
                   'source_map': review['source_map'], 'failures': len(result.failures), 'errors': len(result.errors)}, f, indent=2); f.write('\n')
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__': raise SystemExit(main())
