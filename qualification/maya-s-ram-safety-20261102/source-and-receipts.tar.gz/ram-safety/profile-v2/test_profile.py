"""New serving delta only. Real local HTTP transport, synthetic memory and files."""
import ast
import copy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import http.client
import json
import os
from pathlib import Path
import tempfile
import threading
import types
import unittest
from unittest.mock import patch

import memory_admission as memory
import prepare_profile as recipe
import ram_activate as activation

HERE = Path(__file__).resolve().parent


def functions():
    source = recipe.server_source((HERE / 'server.base.py').read_text())
    tree = ast.parse(source)
    service = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'Service')
    reserve = next(n for n in service.body if isinstance(n, ast.FunctionDef) and n.name == 'reserve_inference')
    factory = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'make_handler')
    handler = next(n for n in factory.body if isinstance(n, ast.ClassDef) and n.name == 'Handler')
    post = next(n for n in handler.body if isinstance(n, ast.FunctionDef) and n.name == '_post')
    scope = {'check_memory': memory.check_memory, 'MemoryPressureError': memory.MemoryPressureError,
             'os': os, 'json': json, 'V1_V1_ALIASES': {},
             'responses_error_body': lambda msg, typ='server_error', code=None: {'error': {'type': typ, 'message': msg, 'code': code}}}
    exec(compile(ast.Module(body=[reserve, post], type_ignores=[]), '<actual-reviewed-server-methods>', 'exec'), scope)
    return scope


class ProfileTests(unittest.TestCase):
    def test_config_changes_only_saved_state_ram_policy(self):
        base = json.loads((HERE / 'config.base.json').read_text()); candidate = recipe.config(base)
        self.assertTrue(recipe.config_contract(base, candidate))
        restored = copy.deepcopy(candidate); restored['env']['STRATA_DS4_SLOT_CAP'] = '4'; del restored['env']['STRATA_DS4_SLOT_RAM_GB']
        self.assertEqual(base, restored)

    def test_model_quality_context_output_changes_rejected(self):
        base = json.loads((HERE / 'config.base.json').read_text())
        for key, value in [('hosted_default_effort', 50), ('fit_max_tokens', True), ('exe', '/different/model')]:
            candidate = recipe.config(base); candidate[key] = value
            with self.assertRaises(ValueError): recipe.config_contract(base, candidate)
        candidate = recipe.config(base); candidate['args'] += ['--max-context', '262144']
        with self.assertRaises(ValueError): recipe.config_contract(base, candidate)

    def test_native_cache_and_drafter_identity_preserved(self):
        base = json.loads((HERE / 'config.base.json').read_text()); candidate = recipe.config(base)
        self.assertEqual(base['args'], candidate['args'])
        self.assertEqual(base['env']['STRATA_DS4_SLOT_DIR'], candidate['env']['STRATA_DS4_SLOT_DIR'])
        for key in ['DS4_DSPARK_MAX', 'DS4_REQUIRE_ALL_RAM', 'DS4_STREAM', 'DS4_TP_CHECK', 'DS4_Q8_CHECK']:
            self.assertEqual(base['env'][key], candidate['env'][key])

    def test_native_ram_budget_is_soft_not_capacity_limit(self):
        config = recipe.config(json.loads((HERE / 'config.base.json').read_text()))
        self.assertEqual(config['env']['STRATA_DS4_SLOT_RAM_GB'], '2')
        self.assertEqual(config['env']['STRATA_DS4_SLOT_CAP'], '2')
        self.assertEqual(config['env']['STRATA_DS4_SLOT_GB'], '8')

    def test_new_preflight_accepts_only_expected_cache_policy(self):
        scope = {'__name__': 'fixture_preflight'}
        exec(compile(recipe.preflight_source((HERE / 'preflight.base.py').read_text()), '<reviewed-preflight>', 'exec'), scope)
        config = recipe.config(json.loads((HERE / 'config.base.json').read_text())); scope['validate_config'](config)
        for key in ['STRATA_DS4_SLOT_CAP', 'STRATA_DS4_SLOT_RAM_GB']:
            bad = copy.deepcopy(config); bad['env'][key] = '4'
            with self.assertRaises(RuntimeError): scope['validate_config'](bad)

    def test_exact_source_anchors_and_syntax(self):
        for fn, name in [(recipe.server_source, 'server.base.py'), (recipe.preflight_source, 'preflight.base.py'), (recipe.ready_source, 'ready.base.py')]:
            text = (HERE / name).read_text(); compile(fn(text), '<reviewed-candidate>', 'exec')
            with self.assertRaises(ValueError): fn(text + '\n' + text)

    def test_no_unrelated_server_method_changed(self):
        old = ast.parse((HERE / 'server.base.py').read_text()); new = ast.parse(recipe.server_source((HERE / 'server.base.py').read_text()))
        def normalized(tree):
            class Strip(ast.NodeTransformer):
                def visit_ImportFrom(self, node):
                    return None if node.module == 'serve.memory_admission' else node
                def visit_FunctionDef(self, node):
                    if node.name in ('reserve_inference', '_post'): node.body = [ast.Pass()]
                    return self.generic_visit(node)
            return ast.dump(Strip().visit(tree), include_attributes=False)
        self.assertEqual(normalized(old), normalized(new))

    def test_dropin_has_only_optin_guard_environment(self):
        self.assertEqual(recipe.DROPIN.splitlines(), ['[Service]', 'Environment=STRATA_HOST_MEM_MIN_GIB=8', 'Environment=STRATA_HOST_MEM_PSI_MAX=10'])
        self.assertNotIn('MemoryMax', recipe.DROPIN); self.assertNotIn('Restart', recipe.DROPIN)

    def test_ready_keeps_existing_checks_and_requires_actual_ram_note(self):
        base = (HERE / 'ready.base.py').read_text(); candidate = recipe.ready_source(base)
        added = [x for x in candidate.splitlines() if 'RAM conversation budget:' in x]
        self.assertEqual(len(added), 1)
        self.assertEqual(candidate.replace(added[0] + '\n', ''), base)

    def test_fresh_candidate_graph_preserves_all_other_pins(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in activation.INPUTS + ('memory_admission.py',):
                (root / name).write_bytes((HERE / name).read_bytes())
            with patch.object(recipe, 'HERE', root): mapping = recipe.prepare()
            release = json.loads((root / 'candidate/release.json').read_text()); base = json.loads((root / 'release.base.json').read_text())
            self.assertEqual(release['id'], base['id'])
            changed = {str(v) for v in mapping.values()}
            self.assertEqual({k: v for k, v in release['files'].items() if k not in changed},
                             {k: v for k, v in base['files'].items() if k not in changed})
            self.assertTrue(release['ram_policy']['one_large_state_and_serialization_peak_can_exceed_budget'])

    def test_canonical_owner_replacement_fails_closed(self):
        state = {'decode_optimization_current': {'selected_identity': {'start_binding': {'native_pid': 1}}}}
        value = {'active': True, 'status': 'DRAINING_FOR_RAM_MAINTENANCE', 'selected_before': {'native_pid': 2}}
        with self.assertRaises(ValueError): activation.state_update(state, None, value)

    def test_private_phase_blocks_initial_claim(self):
        binding = {'native_pid': 1}
        state = {'active_private_phase': 'foreign', 'decode_optimization_current': {'selected_identity': {'start_binding': binding}}}
        with self.assertRaises(ValueError): activation.state_update(state, None, {'selected_before': binding, 'active': True, 'status': 'DRAINING_FOR_RAM_MAINTENANCE'})

    def test_stopped_owner_is_historical_and_no_live_pid_claim(self):
        binding = {'native_pid': 1}; state = {'decode_optimization_current': {'selected_identity': {'start_binding': binding}}}
        previous = {'selected_before': binding, 'active': True, 'status': 'DRAINING_FOR_RAM_MAINTENANCE'}
        state = activation.state_update(state, None, previous)
        value = dict(previous, status='PUBLISHING_RAM_POLICY')
        state = activation.state_update(state, previous, value)
        self.assertIsNone(state['current_native_pid']); self.assertTrue(state['production_temporarily_stopped'])
        self.assertTrue(state['decode_optimization_current']['selected_identity_historical'])

    def test_verified_terminal_state_keeps_other_evidence(self):
        previous = {'active': True}; state = {'mayas_ram_activation_v2': previous, 'production_restore_in_progress': previous, 'original_OOM': 'failed'}
        identity = {'native_pid': 2, 'start_binding': {'native_pid': 2}}
        value = {'active': False, 'status': 'MAYAS_TP2_RAM_GUARDS_ACTIVE_VERIFIED', 'selected_identity': identity, 'verified': {'passed': True}}
        result = activation.state_update(state, previous, value)
        self.assertFalse(result['production_restore_in_progress']); self.assertFalse(result['production_verification_pending'])
        self.assertEqual(result['current_native_pid'], 2); self.assertEqual(result['original_OOM'], 'failed')

    def test_foreign_claim_not_overwritten(self):
        with self.assertRaises(ValueError): activation.state_update({'mayas_ram_activation_v2': {'foreign': True}}, {'active': True}, {'active': False})


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name); self.mem = root / 'mem'; self.psi = root / 'psi'
        self.mem.write_text('MemAvailable: 16777216 kB\n'); self.psi.write_text('some avg10=0.0 avg60=0 avg300=0 total=0\n')
        self.policy = {'STRATA_HOST_MEM_MIN_GIB': '8'}
        self.scope = functions(); self.scope['check_memory'] = lambda _: memory.check_memory(self.policy, self.mem, self.psi)
        scope = self.scope
        class Service:
            reserve_inference = scope['reserve_inference']
            def __init__(self):
                self.status_lock = threading.Lock(); self.draining = False; self.admission_rejected = 0
                self.admission_reserved = 0; self.limit = None; self.body_reads = 0
            def admission_limit(self): return self.limit
            def release_inference(self): self.admission_reserved -= 1
            def drop_embeddings(self): pass
            def begin_request(self, *_): return None
        self.service = Service(); scope['svc'] = self.service
        class Handler(BaseHTTPRequestHandler):
            _post = scope['_post']; watch_done = None; cancel_event = None; record = None
            def log_message(self, *_): pass
            def _authorized(self):
                if self.headers.get('Authorization') == 'Bearer fixture': return True
                self._json(401, {'error': 'unauthorized'}); return False
            def _foreign_page(self): return False
            def _json(self, status, body, retry_after=None):
                data = json.dumps(body).encode(); self.send_response(status)
                self.send_header('Content-Type', 'application/json'); self.send_header('Content-Length', str(len(data)))
                if retry_after: self.send_header('Retry-After', str(retry_after))
                self.end_headers(); self.wfile.write(data)
            def _body(self):
                scope['svc'].body_reads += 1
                return self.rfile.read(int(self.headers.get('Content-Length', '0')))
            def _openai(self, req): self._json(200, {'fixture': 'healthy', 'received': req})
            def do_POST(self): self._post()
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, kwargs={'poll_interval': 0.01}, daemon=True); self.thread.start()
        self.addCleanup(self.close)

    def close(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(timeout=2)
        self.assertFalse(self.thread.is_alive())

    def request(self, path='/v1/chat/completions', auth=True, body='{}'):
        c = http.client.HTTPConnection(*self.server.server_address, timeout=2)
        try:
            headers = {'Content-Type': 'application/json'}
            if auth: headers['Authorization'] = 'Bearer fixture'
            c.request('POST', path, body, headers); r = c.getresponse()
            return r.status, r.getheader('Retry-After'), json.loads(r.read())
        finally: c.close()

    def test_healthy_request_reservation_and_release(self):
        self.assertEqual(self.request()[0], 200); self.assertEqual(self.service.admission_reserved, 0)
        self.assertEqual(self.service.body_reads, 1)

    def test_low_ram_503_before_body_all_protocols(self):
        self.mem.write_text('MemAvailable: 1024 kB\n')
        for path in ['/v1/chat/completions', '/v1/messages', '/v1/responses']:
            status, retry, body = self.request(path, body='invalid JSON deliberately')
            self.assertEqual((status, retry, body['error']['code']), (503, '5', 'host_memory_pressure'))
        self.assertEqual(self.service.body_reads, 0); self.assertEqual(self.service.admission_reserved, 0)
        self.assertEqual(self.service.admission_rejected, 3)

    def test_authentication_precedes_memory_gate(self):
        self.mem.unlink()
        self.assertEqual(self.request(auth=False)[0], 401)
        self.assertEqual(self.service.admission_rejected, 0); self.assertEqual(self.service.body_reads, 0)

    def test_pressure_and_unreadable_readings_return_503(self):
        self.psi.write_text('some avg10=10.0\n'); self.assertEqual(self.request()[0], 503)
        self.psi.unlink(); self.assertEqual(self.request()[0], 503)
        self.assertEqual(self.service.admission_reserved, 0)

    def test_draining_and_queue_full_keep_original_protocol(self):
        self.service.draining = True; self.assertEqual(self.request()[0], 503)
        self.service.draining = False; self.service.limit = 1; self.service.admission_reserved = 1
        status, _, body = self.request(); self.assertEqual(status, 429); self.assertEqual(body['error']['code'], 'admission_full')
        self.assertEqual(self.service.admission_reserved, 1)

    def test_existing_reservation_not_cancelled_on_pressure(self):
        self.service.admission_reserved = 1; self.mem.write_text('MemAvailable: 1024 kB\n')
        self.assertEqual(self.request()[0], 503); self.assertEqual(self.service.admission_reserved, 1)


if __name__ == '__main__': unittest.main()
