"""FIRST bounded tests for the RAM-only deployment delta; no real model actions."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
ROOT = (Path('/Users/alex/strata-deepseek-qualification-20261024') if sys.platform == 'darwin'
        else Path('/home/alex/strata-deepseek-test-20261024'))
DRIVER = ROOT / 'reliability-optimization-20261025/decode-optimization-20261028/cpu-iq2xs-upstream623-v1/model-v1/cpu_driver.py'
DRIVER_SHA = '3cbcf0ce9e000035c893d033b2a6fe09e8d555a831d12a08681f5fdbb0de6b71'
NAMES = ('prepare_profile.py', 'ram_activate.py', 'memory_admission.py', 'test_profile.py', 'run_profile_cpu.py')
INPUTS = ('server.base.py', 'config.base.json', 'preflight.base.py', 'ready.base.py', 'release.base.json')
ENV = {'CUDA_VISIBLE_DEVICES': '', 'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1',
       'MKL_NUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1', 'MALLOC_ARENA_MAX': '1',
       'PYTHONDONTWRITEBYTECODE': '1', 'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C'}


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def source_inputs(): return {n: sha(HERE / n) for n in NAMES + INPUTS}


def checked(pin):
    p = HERE / 'PROFILE_SOURCE_REVIEW.json'
    if sha(p) != pin or sha(DRIVER) != DRIVER_SHA: raise ValueError('Exact source/supervisor review')
    r = json.loads(p.read_text())
    if not r['entire_source_tests_and_delta_read'] or r['source_input_map'] != source_inputs():
        raise ValueError('Reviewed source/input drift')
    return r


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--review-sha256', required=True)
    ap.add_argument('--child', action='store_true'); ap.add_argument('--parent', type=int)
    args = ap.parse_args()
    if not sys.flags.isolated or not sys.dont_write_bytecode: raise ValueError('Use Python -I -B')
    review = checked(args.review_sha256)
    spec = importlib.util.spec_from_file_location('profile_CPU_supervisor', DRIVER)
    d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)
    if not args.child:
        out = HERE / ('PROFILE_CPU_FIRST_' + sys.platform); out.mkdir()
        d.environment = lambda: dict(ENV)
        r = d.supervise([sys.executable, '-I', '-B', str(HERE / 'run_profile_cpu.py'), '--review-sha256',
                         args.review_sha256, '--child', '--parent', str(os.getpid())], out)
        print(json.dumps(r), flush=True)
        return 0 if r['returncode'] == 0 and r['error'] is None and not r['cleanup'] else 1
    observed = d.observed(); d.bounds(observed, os.getpid(), args.parent)
    sys.path.insert(0, str(HERE)); import test_profile as tests
    suite = unittest.defaultTestLoader.loadTestsFromModule(tests); ids = d.flatten(suite)
    if ids != review['test_ids']: raise ValueError('Exact ordered controls')
    r = unittest.TextTestRunner(verbosity=2).run(suite)
    if checked(args.review_sha256) != review or d.observed() != observed: raise ValueError('Source/resource drift')
    value = {'passed': r.wasSuccessful(), 'controls': r.testsRun, 'test_ids': ids,
             'failures': len(r.failures), 'errors': len(r.errors), 'source_input_map': source_inputs(),
             'observed': observed, 'supervisor_pid': args.parent, 'isolated': bool(sys.flags.isolated),
             'scope': 'Actual modified server-method HTTP transport with synthetic memory, config/release/source/custody; no GPU'}
    with (HERE / ('PROFILE_CPU_FIRST_' + sys.platform + '.json')).open('x') as f:
        json.dump(value, f, indent=2); f.write('\n')
    return 0 if value['passed'] else 1


if __name__ == '__main__': raise SystemExit(main())
