"""Bounded synthetic tests of the actual readiness observer and first-request gate."""
import argparse
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
import urllib.error
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import memory_admission as memory
import prepare_profile as recipe


class StartupTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name); self.now = 0.0; self.posts = []; self.checks = 0
        self.unsafe_until = 0; self.health_until = 0; self.http_failure = False; self.wrong_answer = False
        config = {'model_name': 'fixture-model', 'log': str(self.root / 'engine.log')}
        (self.root / 'config.json').write_text(json.dumps(config))
        (self.root / 'config.shared-settings.json').write_text('{"max_tokens":262144}')
        (self.root / 'startup-preflight.json').write_text('{"engine_log_offset":0,"profile_seed_sha256":"fixture"}')
        log = ('ds4: RAM conversation budget: 2.15 GB (LRU states spill to the folder; one RAM slot is always kept)\n'
               'ds4: 6490 routed experts on the CPU lane (71.9 GB): 6490 copied into RAM; no disk fallback\n'
               'ds4: TP check passed (fixture) (DS4_TP_CHECK)\nds4: DS4_AR2=1: fixture\n'
               'ds4: CUDA0 layers [0, 42] (tensor parallel 2, part 0)\n'
               'ds4: CUDA1 layers [0, 39] (tensor parallel 2, part 1)\n')
        (self.root / 'engine.log').write_text(log)
        self.scope = {'__name__': 'fixture_ready'}
        exec(compile(recipe.ready_source((HERE / 'ready.base.py').read_text()), '<actual-readiness-observer>', 'exec'), self.scope)
        self.scope['D'] = self.root
        self.scope['time'] = types.SimpleNamespace(monotonic=lambda: self.now, sleep=self.sleep)
        # Old numerical parsing is separately qualified; this audit targets the new scheduling/HTTP delta.
        self.scope['projection_receipt'] = lambda *_: {'enabled': True}
        self.scope['q8_receipt'] = lambda *_: {'passed': True}

    def sleep(self, seconds):
        self.assertGreater(seconds, 0); self.assertLessEqual(seconds, 3)
        self.now += seconds

    def checker(self, env):
        self.checks += 1
        if self.now < self.unsafe_until: raise memory.MemoryPressureError('fixture memory pressure')
        return {'available_bytes': 16*2**30, 'some_avg10': 0.0, 'floor_GiB': 8.0}

    def urlopen(self, request, timeout=None):
        if isinstance(request, str):
            if request.endswith('/health'):
                value = {'loaded': self.now >= self.health_until, 'max_context': 1048576, 'images': True}
            else: value = {'data': [{'id': 'fixture-model'}]}
        else:
            self.assertTrue(request.full_url.endswith('/v1/chat/completions'))
            self.posts.append(self.now)
            self.assertEqual(timeout, 180)
            body = json.loads(request.data); self.assertEqual(body['max_tokens'], 256)
            if self.http_failure:
                raise urllib.error.HTTPError(request.full_url, 503, 'fixture', None,
                                             io.BytesIO(b'{"error":{"code":"host_memory_pressure"}}'))
            value = {'choices': [{'finish_reason': 'stop', 'message': {'content': 'WRONG' if self.wrong_answer else 'READY'}}]}
        return io.BytesIO(json.dumps(value).encode())

    def run_ready(self):
        package = types.ModuleType('serve'); package.__path__ = []
        module = types.ModuleType('serve.memory_admission')
        module.wait_for_safe_memory = lambda env, deadline: memory.wait_for_safe_memory(
            env, deadline, checker=self.checker, clock=lambda: self.now, sleep=self.sleep)
        with patch.dict(sys.modules, {'serve': package, 'serve.memory_admission': module}), \
                patch.object(sys, 'path', list(sys.path)), \
                patch.object(self.scope['urllib'].request, 'urlopen', self.urlopen), \
                patch.dict(os.environ, {'STRATA_HOST_MEM_MIN_GIB': '8', 'INVOCATION_ID': 'fixture-invocation'}):
            self.scope['main']()

    def test_pressure_waits_before_first_and_only_post(self):
        self.unsafe_until = 6; self.run_ready()
        self.assertEqual(self.posts, [6]); self.assertEqual(self.checks, 3)
        saved = json.loads((self.root / 'startup-memory-admission.json').read_text())
        self.assertTrue(saved['before_first_readiness_POST']); self.assertEqual(saved['invocation'], 'fixture-invocation')
        self.assertEqual(json.loads((self.root / 'startup-ready.json').read_text())['max_output_tokens'], 262144)

    def test_healthy_memory_does_not_delay_first_post(self):
        self.run_ready(); self.assertEqual(self.posts, [0]); self.assertEqual(self.checks, 1)

    def test_health_and_memory_share_existing_deadline(self):
        self.health_until = 3; self.unsafe_until = 2000
        with self.assertRaises(memory.MemoryPressureError): self.run_ready()
        self.assertEqual(self.now, 1100); self.assertEqual(self.posts, [])

    def test_unsafe_until_deadline_never_launches_inference(self):
        self.unsafe_until = 2000
        with self.assertRaises(memory.MemoryPressureError): self.run_ready()
        self.assertEqual(self.now, 1100); self.assertFalse((self.root / 'startup-ready.json').exists())
        self.assertEqual(self.posts, [])

    def test_http503_is_preserved_and_not_retried(self):
        self.http_failure = True
        with self.assertRaises(urllib.error.HTTPError): self.run_ready()
        self.assertEqual(self.posts, [0])
        failure = json.loads((self.root / 'startup-readiness-http-failure.json').read_text())
        self.assertEqual(failure['status'], 503); self.assertFalse(failure['inference_retried'])

    def test_wrong_answer_remains_failure_no_retry(self):
        self.wrong_answer = True
        with self.assertRaises(RuntimeError): self.run_ready()
        self.assertEqual(self.posts, [0]); self.assertFalse((self.root / 'startup-ready.json').exists())

    def test_missing_native_ram_note_still_blocks_success(self):
        p = self.root / 'engine.log'; p.write_text('\n'.join(x for x in p.read_text().splitlines() if 'RAM conversation budget:' not in x))
        with self.assertRaises(RuntimeError): self.run_ready()
        self.assertEqual(self.posts, [0]); self.assertFalse((self.root / 'startup-ready.json').exists())

    def test_gate_never_calls_checker_after_expired_deadline(self):
        self.now = 10
        with self.assertRaises(memory.MemoryPressureError):
            memory.wait_for_safe_memory({}, 10, checker=self.checker, clock=lambda: self.now, sleep=self.sleep)
        self.assertEqual(self.checks, 0)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--review-sha256', required=True)
    ap.add_argument('--child', action='store_true'); ap.add_argument('--parent', type=int); args = ap.parse_args()
    sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    review_file = HERE / 'STARTUP_REVIEW.json'
    if sha(review_file) != args.review_sha256: raise ValueError('Exact manually read startup audit')
    review = json.loads(review_file.read_text())
    if not review['entire_source_tests_read'] or {n: sha(HERE/n) for n in review['source_map']} != review['source_map']:
        raise ValueError('Startup source/input drift')
    root = Path('/Users/alex/strata-deepseek-qualification-20261024') if sys.platform == 'darwin' else Path('/home/alex/strata-deepseek-test-20261024')
    driver = root / 'reliability-optimization-20261025/decode-optimization-20261028/cpu-iq2xs-upstream623-v1/model-v1/cpu_driver.py'
    if sha(driver) != '3cbcf0ce9e000035c893d033b2a6fe09e8d555a831d12a08681f5fdbb0de6b71': raise ValueError('Qualified bounded CPU supervisor')
    spec = importlib.util.spec_from_file_location('bounded_startup', driver); d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)
    if not args.child:
        out = HERE / ('STARTUP_CPU_FIRST_' + sys.platform); out.mkdir()
        d.environment = lambda: {**d.ENV, 'PATH': '/usr/bin:/bin'}
        result = d.supervise([sys.executable, '-I', '-B', str(HERE / 'startup_controls.py'), '--review-sha256',
                              args.review_sha256, '--child', '--parent', str(os.getpid())], out)
        print(json.dumps(result)); return 0 if result['returncode'] == 0 and not result['error'] and not result['cleanup'] else 1
    ob = d.observed(); d.bounds(ob, os.getpid(), args.parent)
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(StartupTests); ids = d.flatten(suite)
    if ids != review['test_ids']: raise ValueError('Exact startup controls')
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    with (HERE / ('STARTUP_CPU_FIRST_' + sys.platform + '.json')).open('x') as f:
        json.dump({'passed': result.wasSuccessful(), 'controls': result.testsRun, 'test_ids': ids, 'observed': ob,
                   'source_map': review['source_map'], 'failures': len(result.failures), 'errors': len(result.errors)}, f, indent=2); f.write('\n')
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__': raise SystemExit(main())
