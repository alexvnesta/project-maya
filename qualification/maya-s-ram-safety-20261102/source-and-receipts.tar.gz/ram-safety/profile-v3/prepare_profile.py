"""Pure, narrow recipe for the same Maya-S engine with RAM safeguards."""
import copy
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
D = Path('/home/alex/deepseek-hosted-20261025')
UNIT_POLICY = Path('/home/alex/.config/systemd/user/deepseek-hosted.service.d/60-memory-admission.conf')
# The model release stays the same. The new deployment revision and file/config
# hashes identify these RAM-only serving changes.
RELEASE = 'deepseek-maya-s-tp2-1m-vision-q8-yoco1-output256k-20261101'
DROPIN = '[Service]\nEnvironment=STRATA_HOST_MEM_MIN_GIB=8\nEnvironment=STRATA_HOST_MEM_PSI_MAX=10\n'


def require(ok, why):
    if not ok: raise ValueError(why)


def replace_once(text, old, new):
    require(text.count(old) == 1, 'Exact reviewed source anchor required')
    return text.replace(old, new, 1)


def config(base):
    result = copy.deepcopy(base)
    require(result['env']['STRATA_DS4_SLOT_CAP'] == '4' and 'STRATA_DS4_SLOT_RAM_GB' not in result['env'],
            'Exact old count-only cache policy')
    result['env']['STRATA_DS4_SLOT_CAP'] = '2'
    result['env']['STRATA_DS4_SLOT_RAM_GB'] = '2'
    return result


def config_contract(base, candidate):
    require(candidate == config(base), 'Only saved-conversation RAM count/bytes may change')
    return True


def server_source(base):
    text = replace_once(base, 'from serve import runconfig  # noqa: E402\n',
                        'from serve import runconfig  # noqa: E402\n'
                        'from serve.memory_admission import check_memory, MemoryPressureError  # noqa: E402\n')
    text = replace_once(text, '            limit = self.admission_limit()\n',
                        '            try:\n'
                        '                check_memory(os.environ)\n'
                        '            except MemoryPressureError:\n'
                        '                self.admission_rejected += 1\n'
                        '                raise\n'
                        '            limit = self.admission_limit()\n')
    return replace_once(text, '            except EngineNonFinite as e:                    # #879, twice: not the request\'s fault\n',
                        '            except MemoryPressureError as e:\n'
                        '                error = {"type": "server_error", "code": "host_memory_pressure", "message": str(e)}\n'
                        '                body = responses_error_body(str(e), "server_error", code=error["code"]) \\\n'
                        '                    if path == "/v1/responses" else {"error": error}\n'
                        '                self._json(503, body, retry_after=5)\n'
                        '            except EngineNonFinite as e:                    # #879, twice: not the request\'s fault\n')


def preflight_source(base):
    text = replace_once(base, 'import datetime, fcntl, hashlib, json, pathlib, shutil, socket, subprocess, sys\n',
                        'import datetime, fcntl, hashlib, json, os, pathlib, shutil, socket, subprocess, sys\n')
    text = replace_once(text, "    env=config.get('env',{})\n",
                        "    env=config.get('env',{})\n"
                        "    if env.get('STRATA_DS4_SLOT_CAP')!='2' or env.get('STRATA_DS4_SLOT_RAM_GB')!='2':raise RuntimeError('Saved-state RAM policy changed')\n")
    return replace_once(text, '    validate_config(config)\n',
                        '    validate_config(config)\n'
                        "    if os.environ.get('STRATA_HOST_MEM_MIN_GIB')!='8' or os.environ.get('STRATA_HOST_MEM_PSI_MAX')!='10':raise RuntimeError('Host memory admission policy missing')\n")


def ready_source(base):
    text = replace_once(base, "    cfg=json.loads((D/'config.json').read_text());base=",
                        "    import os, sys\n"
                        "    sys.path.insert(0,str(D/'runtime-native-vision-v2'))\n"
                        "    from serve.memory_admission import wait_for_safe_memory\n"
                        "    cfg=json.loads((D/'config.json').read_text());base=")
    text = replace_once(text, "    body={'model':cfg['model_name']",
                        "    gate=wait_for_safe_memory(os.environ,deadline)\n"
                        "    (D/'startup-memory-admission.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'invocation':os.environ.get('INVOCATION_ID'),'readings':gate,'before_first_readiness_POST':True},indent=2)+'\\n')\n"
                        "    body={'model':cfg['model_name']")
    old_post = "    with urllib.request.urlopen(urllib.request.Request(base+'/v1/chat/completions',data=json.dumps(body).encode(),headers={'Content-Type':'application/json'}),timeout=180) as f:answer=json.load(f)\n"
    text = replace_once(text, old_post,
                        "    try:\n" + '    ' + old_post +
                        "    except urllib.error.HTTPError as error:\n"
                        "        (D/'startup-readiness-http-failure.json').write_text(json.dumps({'status':error.code,'body':error.read(4096).decode('utf-8',errors='replace'),'inference_retried':False},indent=2)+'\\n')\n"
                        "        raise\n")
    return replace_once(text, '    copies=re.findall(',
                        "    if 'RAM conversation budget: 2.15 GB (LRU states spill to the folder; one RAM slot is always kept)' not in native_log:raise RuntimeError('Native saved-state RAM budget not active')\n"
                        '    copies=re.findall(')


def prepare():
    out = HERE / 'candidate'; out.mkdir(exist_ok=False)
    items = {'config.json': json.dumps(config(json.loads((HERE / 'config.base.json').read_text())), indent=2) + '\n',
             'server.py': server_source((HERE / 'server.base.py').read_text()),
             'hosting_preflight.py': preflight_source((HERE / 'preflight.base.py').read_text()),
             'hosting_ready.py': ready_source((HERE / 'ready.base.py').read_text()),
             'memory_admission.py': (HERE / 'memory_admission.py').read_text(),
             '60-memory-admission.conf': DROPIN}
    for name, value in items.items():
        with (out / name).open('x') as f: f.write(value)
    release = json.loads((HERE / 'release.base.json').read_text())
    files = dict(release['files'])
    mapping = {'config.json': D / 'config.json', 'server.py': D / 'runtime-native-vision-v2/serve/server.py',
               'hosting_preflight.py': D / 'hosting_preflight.py', 'hosting_ready.py': D / 'hosting_ready.py',
               'memory_admission.py': D / 'runtime-native-vision-v2/serve/memory_admission.py',
               '60-memory-admission.conf': UNIT_POLICY}
    for name, dest in mapping.items(): files[str(dest)] = hashlib.sha256((out / name).read_bytes()).hexdigest()
    release.update(id=RELEASE, files=files, status='QUALIFIED_RAM_PROFILE_NOT_YET_ACTIVE', production_active=False)
    release['deployment_revision'] = 'ramguard-20261102'
    release['ram_policy'] = {'saved_RAM_slots': 2, 'saved_RAM_GiB_soft': 2, 'one_large_state_and_serialization_peak_can_exceed_budget': True,
                             'new_request_min_available_GiB': 8, 'memory_some_avg10_reject_at_percent': 10,
                             'new_request_pressure_status': 503, 'active_request_cancelled_by_guard': False,
                             'native_model_capacity_quality_unchanged': True}
    with (out / 'release.json').open('x') as f: json.dump(release, f, indent=2); f.write('\n')
    return mapping


if __name__ == '__main__':
    print(json.dumps({k: str(v) for k, v in prepare().items()}))
