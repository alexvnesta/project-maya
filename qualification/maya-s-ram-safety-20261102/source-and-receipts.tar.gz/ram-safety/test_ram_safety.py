import errno
import json
import os
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

import shm_quarantine as s
import memory_admission as m


class QuarantineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def file(self, name='a' * 32, data=b'fixture only'):
        p = self.root / name; p.write_bytes(data)
        return p

    def test_candidates_exclude_recent_and_unrecognized(self):
        self.file(); self.file('sem.not-ours'); self.file('persistent-cache')
        self.assertEqual(s.candidates(self.root, os.getuid(), time.time()), [])
        rows = s.candidates(self.root, os.getuid(), time.time() + 8 * 86400)
        self.assertEqual([r['name'] for r in rows], ['a' * 32])

    def test_candidates_exclude_alias_and_wrong_owner(self):
        p = self.file(); os.link(p, self.root / ('b' * 32))
        (self.root / ('c' * 32)).symlink_to(p)
        self.assertEqual(s.candidates(self.root, os.getuid(), time.time() + 8 * 86400), [])
        p.unlink()
        self.assertEqual(s.candidates(self.root, os.getuid() + 1, time.time() + 8 * 86400), [])

    def test_candidates_include_only_narrow_uuid_families(self):
        names = ['a' * 31, 'b' * 32 + '_b', 'c' * 32 + '_ll']
        for n in names + ['d' * 32 + '_unknown', '../escape'.replace('/', '_')]: self.file(n)
        rows = s.candidates(self.root, os.getuid(), time.time() + 8 * 86400)
        self.assertEqual([r['name'] for r in rows], names)

    def test_resource_bounded_batches(self):
        rows = [{'name': str(i), 'fingerprint': [0, i, 2**30]} for i in range(9)]
        self.assertEqual([len(b) for b in s.batches(rows)], [4, 4, 1])
        rows = [{'name': str(i), 'fingerprint': [0, i, 0]} for i in range(100)]
        self.assertEqual([len(b) for b in s.batches(rows)], [96, 4])

    def test_copy_complete_disk_verification_source_retained(self):
        p = self.file(data=b'fixture' * 100000); dst = self.root / 'backup'
        expected = s.fingerprint(p.stat())
        result = s.copy_verified(p, dst, expected)
        self.assertEqual(result, s.digest(p)); self.assertEqual(dst.read_bytes(), p.read_bytes())
        self.assertEqual(s.fingerprint(p.stat()), expected)
        self.assertEqual(dst.stat().st_mode & 0o777, 0o600)

    def test_changed_source_refused(self):
        p = self.file(); expected = s.fingerprint(p.stat()); p.write_bytes(b'changed')
        with self.assertRaises(ValueError): s.copy_verified(p, self.root / 'backup', expected)
        self.assertTrue(p.exists()); self.assertFalse((self.root / 'backup').exists())

    def test_copy_failure_preserves_source(self):
        p = self.file()
        with patch.object(s, 'digest', return_value='wrong'):
            with self.assertRaises(ValueError): s.copy_verified(p, self.root / 'backup', s.fingerprint(p.stat()))
        self.assertEqual(p.read_bytes(), b'fixture only'); self.assertTrue((self.root / 'backup').exists())

    def test_archive_collision_and_symlink_refused(self):
        p = self.file(); dst = self.root / 'backup'; dst.symlink_to(p)
        with self.assertRaises(FileExistsError): s.copy_verified(p, dst, s.fingerprint(p.stat()))
        alias = self.root / 'alias'; alias.symlink_to(p)
        with self.assertRaises(OSError): s.copy_verified(alias, self.root / 'new', s.fingerprint(p.stat()))

    def test_release_only_verified_unreferenced_object(self):
        p = self.file(); expected = s.fingerprint(p.stat()); dst = self.root / 'backup'
        s.copy_verified(p, dst, expected)
        s.release_verified(p, expected, {tuple(expected[:2]): []})
        self.assertFalse(p.exists()); self.assertEqual(dst.read_bytes(), b'fixture only')

    def test_new_live_reference_blocks_release(self):
        p = self.file(); expected = s.fingerprint(p.stat())
        with self.assertRaises(ValueError):
            s.release_verified(p, expected, {tuple(expected[:2]): [{'pid': 42}]})
        self.assertTrue(p.exists())

    def test_changed_or_missing_reference_receipt_blocks_release(self):
        p = self.file(); expected = s.fingerprint(p.stat()); p.write_bytes(b'new')
        with self.assertRaises(ValueError): s.release_verified(p, expected, {tuple(expected[:2]): []})
        with self.assertRaises(KeyError): s.release_verified(p, expected, {})
        self.assertEqual(p.read_bytes(), b'new')

    def proc_fixture(self, source, mapping=True, descriptor=True):
        proc = self.root / 'proc'; proc.mkdir(); pid = proc / '42'; pid.mkdir(); (pid / 'fd').mkdir()
        st = source.stat(); dev = '%x:%x' % (os.major(st.st_dev), os.minor(st.st_dev))
        text = '1000-2000 rw-s 00000000 %s %d /alias/not-original-name\n' % (dev, st.st_ino) if mapping else ''
        (pid / 'maps').write_text(text); (pid / 'comm').write_text('fixture-worker\n')
        if descriptor: (pid / 'fd/3').symlink_to(source)
        return proc, (st.st_dev, st.st_ino)

    def test_mapping_alias_counts_as_live_reference(self):
        proc, key = self.proc_fixture(self.file(), descriptor=False)
        self.assertEqual(s.references({key}, proc)[key], [{'pid': 42, 'comm': 'fixture-worker'}])

    def test_descriptor_alias_counts_as_live_reference(self):
        proc, key = self.proc_fixture(self.file(), mapping=False)
        self.assertEqual(len(s.references({key}, proc)[key]), 1)

    def test_no_reference_and_malformed_map(self):
        proc, key = self.proc_fixture(self.file(), mapping=False, descriptor=False)
        self.assertEqual(s.references({key}, proc)[key], [])
        (proc / '42/maps').write_text('malformed\n')
        with self.assertRaises(ValueError): s.references({key}, proc)

    def test_missing_live_process_receipt_fails_closed(self):
        proc, key = self.proc_fixture(self.file()); (proc / '42/maps').unlink()
        with self.assertRaises(ValueError): s.references({key}, proc)

    def test_unreadable_process_fails_closed(self):
        proc, key = self.proc_fixture(self.file())
        with patch.object(Path, 'read_text', side_effect=PermissionError(errno.EACCES, 'fixture')):
            with self.assertRaises(PermissionError): s.references({key}, proc)

    def test_atomic_receipts_never_overwrite(self):
        p = self.root / 'receipt'; s.emit_new(p, {'first': True})
        with self.assertRaises(FileExistsError): s.emit_new(p, {'second': True})
        self.assertEqual(json.loads(p.read_text()), {'first': True})


class AdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name); self.mem = self.root / 'meminfo'; self.psi = self.root / 'pressure'
        self.mem.write_text('MemTotal: 128000000 kB\nMemAvailable: 16777216 kB\n')
        self.psi.write_text('some avg10=0.10 avg60=0.00 avg300=0.00 total=1\nfull avg10=0.00 avg60=0.00 avg300=0.00 total=0\n')
        self.env = {'STRATA_HOST_MEM_MIN_GIB': '8', 'STRATA_HOST_MEM_PSI_MAX': '10'}

    def test_disabled_default_does_not_read_host(self):
        self.mem.unlink(); self.psi.unlink(); self.assertIsNone(m.check_memory({}, self.mem, self.psi))

    def test_healthy_admission(self):
        self.assertEqual(m.check_memory(self.env, self.mem, self.psi)['available_bytes'], 16 * 2**30)

    def test_low_memory_refused(self):
        self.mem.write_text('MemAvailable: 8388607 kB\n')
        with self.assertRaises(m.MemoryPressureError): m.check_memory(self.env, self.mem, self.psi)

    def test_exact_floor_allowed(self):
        self.mem.write_text('MemAvailable: 8388608 kB\n')
        self.assertEqual(m.check_memory(self.env, self.mem, self.psi)['available_bytes'], 8 * 2**30)

    def test_pressure_refused_at_threshold(self):
        self.psi.write_text('some avg10=10.00 avg60=0 avg300=0 total=0\n')
        with self.assertRaises(m.MemoryPressureError): m.check_memory(self.env, self.mem, self.psi)

    def test_invalid_policy_refused(self):
        for key, values in [('STRATA_HOST_MEM_MIN_GIB', ['nan', 'inf', '-1', '0', 'junk']),
                            ('STRATA_HOST_MEM_PSI_MAX', ['nan', 'inf', '-1', '0', '101'])]:
            for value in values:
                with self.subTest(key=key, value=value):
                    env = dict(self.env); env[key] = value
                    with self.assertRaises(m.MemoryPressureError): m.check_memory(env, self.mem, self.psi)

    def test_missing_bad_or_nonfinite_readings_refused(self):
        for data in ['', 'MemAvailable: -1 kB\n', 'MemAvailable: 16 MB\n', 'MemAvailable: 16\n']:
            self.mem.write_text(data)
            with self.assertRaises(m.MemoryPressureError): m.check_memory(self.env, self.mem, self.psi)
        self.mem.write_text('MemAvailable: 16777216 kB\n')
        for data in ['', 'some avg10=nan\n', 'some avg10=-1\n', 'some avg10=101\n']:
            self.psi.write_text(data)
            with self.assertRaises(m.MemoryPressureError): m.check_memory(self.env, self.mem, self.psi)
        self.psi.unlink()
        with self.assertRaises(m.MemoryPressureError): m.check_memory(self.env, self.mem, self.psi)


if __name__ == '__main__':
    unittest.main()
