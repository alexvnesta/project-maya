"""One source-qualified RAM-policy activation, reusing the qualified owned lifecycle.

No native rebuild, GPU experiment, model change, automatic retry, or action on import.
"""
import argparse
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import prepare_profile as recipe

E = Path('/home/alex/strata-deepseek-test-20261024/reliability-optimization-20261025')
P4 = E / 'decode-optimization-20261028/mayas-tp2-production-v4'
D = recipe.D
SOURCES = ('prepare_profile.py', 'ram_activate.py', 'memory_admission.py', 'test_profile.py', 'run_profile_cpu.py')
INPUTS = ('server.base.py', 'config.base.json', 'preflight.base.py', 'ready.base.py', 'release.base.json')
PHASES = ('active_private_phase', 'active_GPU_phase', 'active_gpu_experiment', 'private_window',
          'active_cpu_build', 'production_restore_in_progress', 'production_temporarily_stopped')


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
def require(ok, why):
    if not ok: raise ValueError(why)


def support():
    sys.path.insert(0, str(P4)); import activate_mayas as previous
    require(Path(previous.__file__) == P4 / 'activate_mayas.py', 'Existing owner module origin')
    oldq = previous.qualified(previous.sha(P4 / 'qualification.json'))
    _, owner, _, legacy = previous.support(oldq)
    return previous, oldq, owner, legacy


def qualified(pin):
    require(sha(HERE / 'qualification.json') == pin, 'Exact new RAM qualification')
    q = read(HERE / 'qualification.json')
    review = read(HERE / 'PROFILE_SOURCE_REVIEW.json')
    require(review['entire_source_tests_and_delta_read'] is True, 'Manual source review')
    for n, expected in q['source_input_map'].items(): require(sha(HERE / n) == expected, 'Source/input drift: ' + n)
    require(q['source_input_map'] == review['source_input_map'], 'Exact reviewed map')
    for platform in ('darwin', 'linux'):
        r = read(HERE / ('PROFILE_CPU_FIRST_' + platform + '.json'))
        c = read(HERE / ('PROFILE_CPU_FIRST_' + platform) / 'child.json')
        require(r['passed'] is True and r['test_ids'] == review['test_ids'] and r['source_input_map'] == q['source_input_map']
                and r['failures'] == r['errors'] == 0 and c['returncode'] == 0 and c['error'] is None and c['cleanup'] == []
                and r['observed']['cpu'] == [30, 30] and r['observed']['nice'] == 15
                and r['observed']['as'] == ([512*2**20]*2 if platform == 'linux' else None), 'Both physical bounded CPU proofs')
    recipe.config_contract(read(HERE / 'config.base.json'), read(HERE / 'candidate/config.json'))
    for n, expected in q['candidate_map'].items(): require(sha(HERE / 'candidate' / n) == expected, 'Candidate drift')
    return q


def target_host(previous, owner, legacy, q):
    class RamHost(previous.production_host(owner, legacy, q)):
        def target_identity(self):
            value = super().target_identity()
            cfg = read(D / 'config.json'); recipe.config_contract(read(HERE / 'config.base.json'), cfg)
            env = dict(x.split('=', 1) for x in (Path('/proc') / str(self.start_binding['main_pid']) / 'environ').read_text().split('\0') if '=' in x)
            require(env.get('STRATA_HOST_MEM_MIN_GIB') == '8' and env.get('STRATA_HOST_MEM_PSI_MAX') == '10', 'Actual API memory-admission policy')
            value['RAM_policy'] = read(D / 'release.json')['ram_policy']
            value['deployment_revision'] = 'ramguard-20261102'
            return value
    return RamHost


def publication_mapping():
    return {'config.json': D / 'config.json', 'server.py': D / 'runtime-native-vision-v2/serve/server.py',
            'hosting_preflight.py': D / 'hosting_preflight.py', 'hosting_ready.py': D / 'hosting_ready.py',
            'memory_admission.py': D / 'runtime-native-vision-v2/serve/memory_admission.py',
            '60-memory-admission.conf': recipe.UNIT_POLICY, 'release.json': D / 'release.json'}


def publish(q, out, previous):
    require(sha(D / 'config.json') == q['base_config_sha256'] and sha(D / 'release.json') == q['base_release_sha256'], 'Original deployment unchanged')
    backup = out / 'before'; backup.mkdir()
    staged = []
    for name, dest in publication_mapping().items():
        require(not dest.is_symlink(), 'No destination alias')
        if name in ('memory_admission.py', '60-memory-admission.conf'):
            require(not dest.exists(), 'New dependency collision')
        dest.parent.mkdir(exist_ok=True)
        require(dest.parent.resolve() == dest.parent, 'Real publication parent')
        if dest.exists(): shutil.copy2(dest, backup / name)
        elif name not in ('memory_admission.py', '60-memory-admission.conf'):
            raise ValueError('Missing existing deployment file')
        else: require(not dest.exists(), 'New dependency collision')
        tmp = dest.with_name(dest.name + '.ramguard-new')
        require(not tmp.exists() and not tmp.is_symlink(), 'No staging residue')
        shutil.copy2(HERE / 'candidate' / name, tmp)
        require(sha(tmp) == q['candidate_map'][name], 'Staged byte identity')
        staged.append((tmp, dest))
    for tmp, dest in staged: os.replace(tmp, dest)
    return {'backup': str(backup), 'model_native_unchanged': True, 'deployment_revision': 'ramguard-20261102'}


def state_update(state, previous_record, value):
    now = copy.deepcopy(state)
    if previous_record is not None:
        require(now.get('mayas_ram_activation') == previous_record and
                now.get('production_restore_in_progress') == (previous_record if previous_record['active'] else False), 'Exact RAM maintenance custody')
    else:
        require(not now.get('mayas_ram_activation') and not any(now.get(k) for k in PHASES), 'No other maintenance owner')
        require(now['decode_optimization_current']['selected_identity']['start_binding'] == value['selected_before'], 'Action-time original binding')
    now['mayas_ram_activation'] = value
    now['production_restore_in_progress'] = value if value['active'] else False
    if value.get('selected_identity'):
        now['decode_optimization_current'] = {'status': value['status'], 'selected_identity': value['selected_identity'],
                                              'RAM_activation': str(HERE / 'activation-FIRST/state.json')}
        now.update(current_native_pid=value['selected_identity']['native_pid'], production_temporarily_stopped=False,
                   production_verification_pending=False if value.get('verified', {}).get('passed') else str(HERE / 'activation-FIRST/state.json'))
    elif value['status'] in ('PUBLISHING_RAM_POLICY', 'STARTING_RAM_POLICY', 'HOLD_RAM_ACTIVATION_NO_RETRY'):
        now.update(current_native_pid=None, production_temporarily_stopped=True, production_verification_pending=False)
        now['decode_optimization_current']['status'] = 'RAM_MAINTENANCE_IDENTITY_HISTORICAL'
        now['decode_optimization_current']['selected_identity_historical'] = True
    return now


def run(pin):
    q = qualified(pin); a, oldq, owner, legacy = support(); cas = a.cas_library(oldq)
    initial = read(E / 'STATE.json'); binding = initial['decode_optimization_current']['selected_identity']['start_binding']
    require(binding == q['selected_binding'] and not any(initial.get(k) for k in PHASES), 'Exact current owner/no phase')
    pending = initial.get('production_verification_pending')
    require(not pending or pending == str(E / 'maintenance/mayas-tp2-oom-recovery-20261102T0243Z/RESULT_FIRST.json'), 'No foreign pending verification')
    old = a.production_host(owner, legacy, oldq)(); old.start_binding = binding; old.restored_pid = binding['native_pid']
    old.guard_binding(); old.target_identity()
    h = old.get('/health'); sw = h['switcher']
    require(h['loaded'] and h['images'] and h['max_context'] == 1048576 and sw['active_model'] == sw['default_model'] == 'deepseek' and sw['fault'] is None, 'Healthy selected default')
    require(shutil.disk_usage('/').free >= 132*2**30, 'Root132 admission')
    out = HERE / 'activation-FIRST'; out.mkdir()
    since = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')
    old.audit_dir = out; old.since = since
    host = target_host(a, owner, legacy, q)(); host.audit_dir = out; host.since = since
    host.start_binding = None; host.restored_pid = None; host.baseline_binding = binding
    value = {'status': 'DRAINING_FOR_RAM_MAINTENANCE', 'active': True, 'selected_before': binding,
             'superseded_public_pending': pending, 'qualification_sha256': pin, 'kernel_since': since,
             'user_authorized_service_interruption': True, 'native_model_quality_capacity_unchanged': True}
    previous = None
    def save(row):
        nonlocal previous
        raw = (E / 'STATE.json').read_bytes(); current = json.loads(raw)
        cas.cas_state(E / 'STATE.json', raw, state_update(current, previous, row))
        previous = copy.deepcopy(row); a.emit(out / 'state.json', row)
    save(value)
    try:
        old.guard_binding(); old.stop_router(); old.guard_binding()
        old.stop_ds(); old.clean_stop(binding['native_pid']); old.free(); old.kernel(since)
        value = dict(value, status='PUBLISHING_RAM_POLICY'); save(value)
        with old.publication_lock(): installed = publish(q, out, a)
        old.command(['systemctl', '--user', 'daemon-reload'], timeout=30)
        value = dict(value, status='STARTING_RAM_POLICY', installation=installed); save(value)
        host.restore_ds(); host.restore_router()
        verified = host.verify_target(expected_pid=host.restored_pid)
        identity = verified.get('selected_identity') or host.target_identity()
        value = dict(value, status='MAYAS_TP2_RAM_GUARDS_ACTIVE_VERIFIED' if verified.get('passed') else 'MAYAS_TP2_RAM_GUARDS_RUNNING_PUBLIC_PENDING',
                     active=False, verified=verified, selected_identity=identity, start_binding=host.start_binding)
        release = read(D / 'release.json'); release.update(status=value['status'], production_active=bool(verified.get('passed')),
                                                         RAM_activation=str(out / 'state.json')); a.emit(D / 'release.json', release)
        save(value); return value
    except BaseException as exc:
        current = read(E / 'STATE.json')
        if current.get('mayas_ram_activation') != previous:
            exc.add_note('Foreign custody: no service signal or canonical state overwrite')
            a.emit(out / 'foreign-custody-error.json', {'error': repr(exc), 'foreign_state_preserved': True})
            raise
        cleanup = None
        if host.start_binding:
            try: host.cleanup_owned_target(host.restored_pid)
            except BaseException as error: cleanup = repr(error)
        value = dict(value, status='HOLD_RAM_ACTIVATION_NO_RETRY', active=True, error=repr(exc), cleanup_error=cleanup,
                     attempted_binding=host.start_binding, original_failed_attempt_preserved=True)
        save(value); raise


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--qualification', required=True)
    args = ap.parse_args(); print(json.dumps(run(args.qualification), allow_nan=False))
