"""Reversible, explicit cleanup of old, unreferenced POSIX shared-memory objects.

Metadata inspection only during planning. Payloads stay on this host, in a private
disk quarantine. No periodic cleanup, model change, service stop, or action on import.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import time

E = Path('/home/alex/strata-deepseek-test-20261024/reliability-optimization-20261025')
AGE_SECONDS = 7 * 86400
MAX_BATCH_BYTES = 4 * 2**30
MAX_BATCH_FILES = 96
NAME = re.compile(r'[0-9a-f]{31,32}(?:_(?:b|g|ll|r|s))?\Z')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def fingerprint(s):
    return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns,
            s.st_uid, s.st_gid, stat.S_IMODE(s.st_mode), s.st_nlink]


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(2**20), b''):
            h.update(b)
    return h.hexdigest()


def emit_new(path, value):
    with Path(path).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n'); f.flush(); os.fsync(f.fileno())


def real_directory(path):
    path = Path(path)
    require(path.is_absolute() and path.resolve() == path and path.is_dir(), 'Real absolute directory required')
    for p in (path, *path.parents):
        require(not p.is_symlink(), 'No directory alias')


def references(keys, proc=Path('/proc')):
    """All process mappings and descriptors, matched by device/inode, including aliases.

    Vanishing processes/FDs are normal. An unreadable process fails the entire audit.
    Only PID/comm is recorded, never arguments, mappings' data, or environment.
    """
    refs = {k: [] for k in keys}
    for p in proc.iterdir():
        if not p.name.isdecimal():
            continue
        found = set()
        try:
            for line in (p / 'maps').read_text().splitlines():
                parts = line.split(None, 5)
                require(len(parts) >= 5, 'Malformed mapping receipt')
                major, minor = (int(v, 16) for v in parts[3].split(':'))
                key = (os.makedev(major, minor), int(parts[4]))
                if key in refs:
                    found.add(key)
            for fd in (p / 'fd').iterdir():
                try:
                    s = fd.stat()
                    key = (s.st_dev, s.st_ino)
                    if key in refs:
                        found.add(key)
                except FileNotFoundError:
                    pass
            if found:
                comm = (p / 'comm').read_text().strip()
                for key in found:
                    refs[key].append({'pid': int(p.name), 'comm': comm})
        except (FileNotFoundError, ProcessLookupError):
            # If it still exists, an incomplete process directory is not proof.
            require(not p.exists(), 'Incomplete live process audit: ' + p.name)
    return refs


def candidates(root, uid, now):
    rows = []
    for p in sorted(root.iterdir()):
        s = p.lstat()
        if (NAME.fullmatch(p.name) and stat.S_ISREG(s.st_mode) and s.st_uid == uid
                and s.st_nlink == 1 and s.st_size <= MAX_BATCH_BYTES
                and max(s.st_mtime, s.st_ctime, s.st_atime) < now - AGE_SECONDS):
            rows.append({'name': p.name, 'fingerprint': fingerprint(s), 'allocated': s.st_blocks * 512})
    return rows


def batches(rows):
    result = []; batch = []; size = 0
    for row in rows:
        n = row['fingerprint'][2]
        if batch and (size + n > MAX_BATCH_BYTES or len(batch) >= MAX_BATCH_FILES):
            result.append(batch); batch = []; size = 0
        batch.append(row); size += n
    if batch:
        result.append(batch)
    return result


def plan(out):
    require(os.geteuid() == 0, 'Root visibility is required for all-process references')
    real_directory(Path('/dev/shm')); real_directory(out.parent)
    require(out.parent.parent == E / 'maintenance', 'Owned maintenance directory only')
    rows = candidates(Path('/dev/shm'), 1000, time.time())
    refs = references({tuple(r['fingerprint'][:2]) for r in rows})
    ready = [r for r in rows if not refs[tuple(r['fingerprint'][:2])]]
    value = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'root': '/dev/shm', 'uid': 1000, 'age_seconds': AGE_SECONDS,
             'archive': str(out.parent / 'quarantine'), 'batches': batches(ready),
             'referenced_excluded': len(rows) - len(ready), 'payload_exported': False,
             'ownership_claim': 'No live references; original producer unknown. Reversible quarantine, not permanent deletion.'}
    emit_new(out, value)
    return {'files': len(ready), 'allocated': sum(r['allocated'] for r in ready), 'batches': len(value['batches'])}


def copy_verified(source, dest, expected):
    """Copy without following an alias, fsync, and compare the complete on-disk copy.

    The source survives all copy failures. A partial destination stays as evidence.
    """
    flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NOATIME', 0)
    fd = os.open(source, flags)
    try:
        require(fingerprint(os.fstat(fd)) == expected, 'Source changed before copy')
        h = hashlib.sha256()
        with dest.open('xb') as f:
            os.chmod(dest, 0o600)
            while True:
                block = os.read(fd, 2**20)
                if not block:
                    break
                h.update(block); f.write(block)
            f.flush(); os.fsync(f.fileno())
        require(fingerprint(os.fstat(fd)) == expected, 'Source changed during copy')
        require(dest.stat().st_size == expected[2] and digest(dest) == h.hexdigest(), 'Disk copy differs')
        return h.hexdigest()
    finally:
        os.close(fd)


def release_verified(source, expected, refs):
    """Unlink only the exact frozen object after the fresh complete reference scan."""
    require(not refs[tuple(expected[:2])], 'Object opened during copy; retain original')
    require(fingerprint(source.lstat()) == expected, 'Object changed before unlink')
    source.unlink()


def apply_batch(plan_path, pin, index):
    require(os.geteuid() == 0, 'All-process root audit required')
    real_directory(plan_path.parent)
    require(plan_path.parent.parent == E / 'maintenance' and not plan_path.is_symlink(), 'Owned plan only')
    require(digest(plan_path) == pin, 'Frozen plan changed')
    value = json.loads(plan_path.read_text()); root = Path(value['root']); archive = Path(value['archive'])
    require(root == Path('/dev/shm') and archive == plan_path.parent / 'quarantine', 'Exact source/quarantine')
    require(type(index) is int and 0 <= index < len(value['batches']), 'Explicit batch index')
    rows = value['batches'][index]
    require(0 < len(rows) <= MAX_BATCH_FILES and sum(r['fingerprint'][2] for r in rows) <= MAX_BATCH_BYTES,
            'Batch resource bound')
    require(len({r['name'] for r in rows}) == len(rows), 'Unique names')
    for r in rows:
        require(NAME.fullmatch(r['name']) is not None and r['fingerprint'][5] == 1000
                and r['fingerprint'][8] == 1, 'Narrow owned object shape')
        require(fingerprint((root / r['name']).lstat()) == r['fingerprint'], 'Planned object changed')
    real_directory(root)
    if not archive.exists():
        archive.mkdir(mode=0o700)
    real_directory(archive)
    require(archive.stat().st_uid == 0 and stat.S_IMODE(archive.stat().st_mode) == 0o700, 'Private root-only archive')
    receipt = plan_path.parent / ('batch-%02d-FIRST.jsonl' % index)
    with receipt.open('x', encoding='utf-8') as log:
        def event(v):
            log.write(json.dumps(v, allow_nan=False) + '\n'); log.flush(); os.fsync(log.fileno())
        try:
            keys = {tuple(r['fingerprint'][:2]) for r in rows}
            require(not any(references(keys).values()), 'Object now referenced; no copy or unlink')
            for r in rows:
                dst = archive / r['name']
                require(not dst.exists() and not dst.is_symlink(), 'Archive collision; no replay')
                pin_copy = copy_verified(root / r['name'], dst, r['fingerprint'])
                event({'name': r['name'], 'copied_verified': True, 'sha256': pin_copy})
            # Re-audit after all disk I/O; exclude objects newly mapped/opened.
            refs = references(keys)
            for r in rows:
                release_verified(root / r['name'], r['fingerprint'], refs)
                event({'name': r['name'], 'actual_unlink_returned': True, 'allocated_before': r['allocated']})
            event({'complete': True, 'count': len(rows), 'bytes': sum(r['allocated'] for r in rows)})
        except BaseException as e:
            event({'failed': repr(e), 'no_automatic_retry': True})
            raise
    return {'batch': index, 'files': len(rows), 'allocated_before': sum(r['allocated'] for r in rows)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='action', required=True)
    pp = sub.add_parser('plan'); pp.add_argument('output', type=Path)
    ap = sub.add_parser('apply'); ap.add_argument('plan', type=Path)
    ap.add_argument('--sha256', required=True); ap.add_argument('--batch', type=int, required=True)
    args = parser.parse_args()
    result = plan(args.output) if args.action == 'plan' else apply_batch(args.plan, args.sha256, args.batch)
    print(json.dumps(result, allow_nan=False))


if __name__ == '__main__':
    main()
